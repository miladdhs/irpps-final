-- MySQL dump 10.13  Distrib 8.3.0, for Linux (x86_64)
--
-- Host: mysql    Database: irporg_DB
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_customuser`
--

DROP TABLE IF EXISTS `accounts_customuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_customuser` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `phone` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `bio` longtext COLLATE utf8mb4_unicode_ci,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `experience` int NOT NULL,
  `rating` decimal(3,1) NOT NULL,
  `specialty` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `awards` longtext COLLATE utf8mb4_unicode_ci,
  `certifications` longtext COLLATE utf8mb4_unicode_ci,
  `education` longtext COLLATE utf8mb4_unicode_ci,
  `languages` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publications` longtext COLLATE utf8mb4_unicode_ci,
  `research_interests` longtext COLLATE utf8mb4_unicode_ci,
  `approval_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved_at` datetime(6) DEFAULT NULL,
  `approved_by_id` bigint DEFAULT NULL,
  `rejection_reason` longtext COLLATE utf8mb4_unicode_ci,
  `requested_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `accounts_customuser_approved_by_id_b5d0fb35_fk_accounts_` (`approved_by_id`),
  CONSTRAINT `accounts_customuser_approved_by_id_b5d0fb35_fk_accounts_` FOREIGN KEY (`approved_by_id`) REFERENCES `accounts_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_customuser`
--

LOCK TABLES `accounts_customuser` WRITE;
/*!40000 ALTER TABLE `accounts_customuser` DISABLE KEYS */;
INSERT INTO `accounts_customuser` VALUES (1,'pbkdf2_sha256$600000$vCqqPfXzNTGNBhnAkf86oj$MTFtOj3PRZ5aOQ43r+ySViVsXSIGB9YGG5zKxNt5QwM=','2025-11-17 05:29:43.375879',1,'admin','Admin','User','admin@ispp.ir',1,'2025-11-06 03:55:33.876259','09134279848','2025-11-06 03:55:33.876259','2026-07-03 18:21:29.332821',1,'System administrator with profile image for testing purposes.','Tehran',5,5.0,'System Administrator','','تست 2','تست3','فوق تخصص','','ریه کودکان ','','approved','2026-07-03 16:51:59.095793',NULL,NULL,'2026-07-03 16:51:59.096223'),(2,'pbkdf2_sha256$600000$PMxlFzuWrbD8YKvSGuHx5e$f4ytlR9vrZc8CduZkJkM8BLV0piwGYOjcRM7aK/IL04=',NULL,0,'4213513513','MD. Ali','baba','alibba@ali.com',0,'2025-11-06 04:19:25.757215','09129120912','2025-11-06 04:19:25.757215','2026-07-03 18:21:29.404732',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.292499'),(3,'pbkdf2_sha256$600000$tygbyIJc9vSNNaIMOneRlj$8WiAI7W7VdfbOEJIYiEolJvaDIJyZOYxs/xV6VIjnDY=',NULL,0,'0779478517','Ebrahim tabiee','ابراهيم طبيعي','asndr370780@yahoo.com',0,'2025-11-06 04:19:25.970054','09155710981','2025-11-06 04:19:25.970054','2026-07-03 18:21:29.409103',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.325036'),(4,'pbkdf2_sha256$600000$hlUo1HLA4p4y4pAfIc1vEy$ADzjuVA687Lp7CmM7segLE9ulo6IEWSbAP++XqeD8wQ=',NULL,0,'1379391611','Azar dastrangi','اذز دسترنجي','dastranji61@gmail.com',0,'2025-11-06 04:19:26.169058','09143111185','2025-11-06 04:19:26.169058','2026-07-03 18:21:29.413367',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.335446'),(5,'pbkdf2_sha256$600000$ozN1PmcT5ldx3ztttJUUEW$a194LO3tducfUT5ZRw/MewsmaeHDlStuOF4YQYFpeW0=',NULL,0,'3149580781','Aazam gholami','اعظم غلامی','aazamgholami67@gmail.com',0,'2025-11-06 04:19:26.366001','09133914741','2025-11-06 04:19:26.366001','2026-07-03 18:21:29.417582',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.350443'),(6,'pbkdf2_sha256$600000$FDrdNuFDHVlZbZV9HTyKzU$p0/ixcy2uK57AurFdbP/kmrMpTDDZHwROUXrdIO/goU=',NULL,0,'0533465982','Akbar Zamani','اکبرزمانی','akbarzmn1@gmail.com',0,'2025-11-06 04:19:26.556329','09183674676','2025-11-06 04:19:26.557249','2026-07-03 18:21:29.421725',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.362107'),(7,'pbkdf2_sha256$600000$ZVCa5iVrzofAlp5fZdtvlI$05AIWeYRMH09yRiTaq5dnG1TecvvpL1W3jj5HA+pgZw=',NULL,0,'1189364344','Nafise Fadavi','نفیسه فدوی','',0,'2025-11-06 04:19:26.746563','913311114','2025-11-06 04:19:26.746563','2026-07-03 18:21:29.425964',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.374027'),(8,'pbkdf2_sha256$600000$WZUNmhALUj8NVNwLQITqro$KMu56EP9ytDeGzlJxlqak35GqDvDGZ1MLQ1Vo9sxkJM=',NULL,0,'1552102661','Elnaz Eskandartash','الناز اسكندرتاش','Elnaz_eskandartah@yahoo.com',0,'2025-11-06 04:19:26.930916','09143210182','2025-11-06 04:19:26.930916','2026-07-03 18:21:29.430338',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.388886'),(9,'pbkdf2_sha256$600000$zy04ROJIUIssWLWNKquGZH$1SWCopNEBsHIkNZD7sbZsj7OG++vNZ4CS9cVe98J1wo=',NULL,0,'2092126423','Elhamsadati','الهام ساداتی','Sadati.dr@gmail.com',0,'2025-11-06 04:19:27.120125','09123750163','2025-11-06 04:19:27.120125','2026-07-03 18:21:29.434801',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.401922'),(10,'pbkdf2_sha256$600000$94bgIbHHG9XjNyJtYtCU5f$cOFcwE3ZPuOtVeTNi3opEkyfN5pSCRQHULzoO5V4L3k=',NULL,0,'2200575440','Amir Rezaei','امیر رضائی','rezaei@dr.com; rezaeia@yahoo.com',0,'2025-11-06 04:19:27.304990','09121579773','2025-11-06 04:19:27.304990','2026-07-03 18:21:29.440195',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.411669'),(11,'pbkdf2_sha256$600000$RABa84nnaChnd2xgNLOTVG$S9UG3Yxw91ZGJfqwRWUSXlUvfijsDlxyWz2t+uv5VzU=',NULL,0,'0383657148','Amir Abbas Besharati','امیر عباس بشارتی','abesharaty@yahoo.com',0,'2025-11-06 04:19:27.488002','09121574256','2025-11-06 04:19:27.488002','2026-07-03 18:21:29.445288',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.419471'),(12,'pbkdf2_sha256$600000$sG1YpN0no1k7IawAvimDsL$CbuxqhnycB+2hk9dLiNjubKlKvHbPRGzENLXEJdiaSM=',NULL,0,'0054708753','Amir_Hossein Jafari_Rouhi','امير حسين جعفري روحي','jafariroohi@yahoo.com',0,'2025-11-06 04:19:27.670525','09143115799','2025-11-06 04:19:27.670525','2026-07-03 18:21:29.450380',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.427567'),(13,'pbkdf2_sha256$600000$UjPpNGRHEhI4yZONAEDgna$k8h1kOelck5LPs2O+eXOg6oEKbzYweSZqt+pl2S1+18=',NULL,0,'1378048725','babak rafizade rashid','بابک رفیع زاده رشید','dbrr1375p@yahoo.com',0,'2025-11-06 04:19:27.855242','09143322186','2025-11-06 04:19:27.855242','2026-07-03 18:21:29.455182',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.447074'),(14,'pbkdf2_sha256$600000$cjHXmUniKfYGpmVM409gnm$0fQs3iUf2t5PFOcZJ5YQEjSD0cz1Fjn6IKt4ZJ+FAjA=',NULL,0,'137998797','Babak Ghalibafsabbaghi','بابک قالیباف صباغی','Bghalibaf@gmail.com',0,'2025-11-06 04:19:28.040077','9143147443','2025-11-06 04:19:28.040077','2026-07-03 18:21:29.459925',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.455356'),(15,'pbkdf2_sha256$600000$4E2MBVgMd7QmPZ2fd2k0me$nlNohcZ9HDDqBr9nv3QwUrFy9cPM3bAs22uJu9kSIbE=',NULL,0,'0081048051','Javad Harati','جواد هراتی','javad.harati6@gmail.com',0,'2025-11-06 04:19:28.228398','09373609366','2025-11-06 04:19:28.228398','2026-07-03 18:21:29.465116',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.468600'),(16,'pbkdf2_sha256$600000$fzJwXVrZM6sv5sHqmULplS$eZ8KI1PQE7OMaygzSwlH/ciu0VT0xiFNoUSQ9dy/C0g=',NULL,0,'1282893777','rohola shirzadi','روح اله شیرزادی','shirzadi123@yahoo.com',0,'2025-11-06 04:19:28.424106','09386082828','2025-11-06 04:19:28.424106','2026-07-03 18:21:29.469836',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.481925'),(17,'pbkdf2_sha256$600000$QbgHADYcLdHdobgHVxDSFH$ZgxPierBbMrNz3RALR/Qm+NmBsZ/U8fxdz//0iDFDF0=',NULL,0,'2571793861','Zahra Roshanzamir','زهرا روشن ضمیر','z.roshanzamir@yahoo.com',0,'2025-11-06 04:19:28.623183','09177311082','2025-11-06 04:19:28.623183','2026-07-03 18:21:29.474706',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.491887'),(18,'pbkdf2_sha256$600000$l60T5h9dcFXVw3zl7se3mo$sfAENA/awGDn9S/w6jVQOD0+ISYfKqpwXjBmEha6tf8=',NULL,0,'2990643761','Sarehosaddat Ebrahimi','ساره السادات ابراهیمی','sareh.ebrahimi913@gmail.com',0,'2025-11-06 04:19:28.812866','09133414248','2025-11-06 04:19:28.812866','2026-07-03 18:21:29.479565',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.502100'),(19,'pbkdf2_sha256$600000$Rn0Pmz6VQc3IjwgR41eUr9$GI/mRQfb4pml8HClhccu+unnB5CBYjBVaAIHWfI5/Bs=',NULL,0,'1288064896','Saeed Sadr','سعید صدر','Ssadr54@yahoo.com',0,'2025-11-06 04:19:29.003966','09133044529','2025-11-06 04:19:29.003966','2026-07-03 18:21:29.484482',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.543132'),(20,'pbkdf2_sha256$600000$y89EW0voczOF9nMAU6oCdQ$ugV3YNDMXYSefb7WGnPWnEifTRBkgdftoO0auXdhkbU=',NULL,0,'3489637232','Saeid Hashemi','سعید هاشمی','Hashemis57@yahoo.com',0,'2025-11-06 04:19:29.204456','09171643063','2025-11-06 04:19:29.204456','2026-07-03 18:21:29.493091',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.564717'),(21,'pbkdf2_sha256$600000$cADM9F8A8TY5p07PS3zFAG$jTerlwWq8t8HtHj0hAx267kWMIKJNdyueQsJ//3hGkg=',NULL,0,'0060017724','Saeid Sadat Mansouri','سعيد   سادات منصوري','sahand8141557@yahoo.com',0,'2025-11-06 04:19:29.409366','09113311147','2025-11-06 04:19:29.409366','2026-07-03 18:21:29.501596',1,'','',0,0.0,'','','','','','','','','approved',NULL,NULL,NULL,'2026-07-03 16:51:59.590079'),(22,'pbkdf2_sha256$600000$eqZyREuNqKQwShN7XUoEAE$f1agZZkTX3WRmICDIIM9sDVAeUL+hW7A9spgftkr8Ow=',NULL,0,'2161792741','Soheila hokmabadi','سهيلا حكم ابادي','Dr_hokmabadi@yahoo.com',0,'2025-11-06 04:19:29.604263','09155409052','2025-11-06 04:19:29.604263','2026-07-03 18:21:29.506414',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.705903'),(23,'pbkdf2_sha256$600000$UZaUTee6ozgZvvfOikutXI$XAiAMSQnKmyeRbuK/D5op/xnXQ43W4/q2Y3iP+bVpNE=',NULL,0,'1460837789','Soheila Khalilzadeh','سهيلا خليل زاده','drkhalilzadeh@gmail.com',0,'2025-11-06 04:19:29.794488','09121187014','2025-11-06 04:19:29.795471','2026-07-03 18:21:29.511363',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.713583'),(24,'pbkdf2_sha256$600000$b7AB51zYd1tAb2uFC3vzgt$y2HiRo98bFAiZNze5aYQNqRJUS5gJQe5qFIMUXYXZQU=',NULL,0,'0452101484','Seid Ahmad Tabatabaee Aghdaee','سید احمد طباطبایی عقدایی','ahmadtabatabaii@gmail.com',0,'2025-11-06 04:19:29.983555','09121599014','2025-11-06 04:19:29.983555','2026-07-03 18:21:29.516578',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.720440'),(25,'pbkdf2_sha256$600000$6XJBPwGUI8aTsGegGx9fAn$nm3m5nTOwYt+Ag3UBrQGvwBrZJoDHDXsWze17qmuVPQ=',NULL,0,'0937787248','Seyed Javad Sayedi','سید جواد سیدی','sayedij@mums.ac.ir',0,'2025-11-06 04:19:30.192417','09155177719','2025-11-06 04:19:30.192417','2026-07-03 18:21:29.521596',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.727466'),(26,'pbkdf2_sha256$600000$tC8X3EoihTrvZihMQA7HI7$SotIRkeqvtO951kSTati2FNWz0rjlVuqY3ag2CL8J5o=',NULL,0,'0943345782','Seyed Mohammadreza Mirkarimi','سید محمدرضا میرکریمی','smohammadreza.mirkarimi@gmail.com',0,'2025-11-06 04:19:30.391875','09124942303','2025-11-06 04:19:30.391875','2026-07-03 18:21:29.526585',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.734570'),(27,'pbkdf2_sha256$600000$d94lPWhJ4TSKmhrmCQoaem$RqpHEC04yHAGqhqXgU/vHq14jmcvXddrM2g8B94bDKU=',NULL,0,'1142227162','Seyed Hossein Mirlohi','سیدحسین میرلوحی','sh.mirlohi2004@gmail.com',0,'2025-11-06 04:19:30.594540','09131020469','2025-11-06 04:19:30.594540','2026-07-03 18:21:29.531634',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.740816'),(28,'pbkdf2_sha256$600000$QVeZDuNf5dwKmjV43VcIBx$t4u+SIFnPsy36G2/vBoRDgEaiNUEvf6I/AtfbOFrMuk=',NULL,0,'2593442972','seyedeh mahsa mirzendehdel','سیده مهسا میرزنده دل','mahsa_mzd@yahoo.com',0,'2025-11-06 04:19:30.788810','09111370092','2025-11-06 04:19:30.788810','2026-07-03 18:21:29.539238',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.747613'),(29,'pbkdf2_sha256$600000$JOISWoaJnXxvxmNZxIakzp$gl9Q2kDdok9l8PqRKVPiN/700oLZbdpqCTCzPcmfJVI=',NULL,0,'3849677923','Shilan Mohammadi','شيلان محمدي','Shilanm3256@gmail.com',0,'2025-11-06 04:19:30.991758','09188710075','2025-11-06 04:19:30.991758','2026-07-03 18:21:29.543964',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.755561'),(30,'pbkdf2_sha256$600000$nPgyRdYDcVm92WpN3NJKjY$jfWf+VX0kQEs7oDIkDedafHWvZBLaItyD4pXjktwBFU=',NULL,0,'2295557070','Sedigheh Yousefzadegan','صدیقه یوسف زادگان','yousefzadegan.s@gmail.com',0,'2025-11-06 04:19:31.203103','09123040490','2025-11-06 04:19:31.203103','2026-07-03 18:21:29.548827',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.761398'),(31,'pbkdf2_sha256$600000$KEPYVcdbSOXbDUay7vSxkX$tC8IZu1o2rceDh/xYEpqYBWR2bzHTKlIubgvWSgKUDs=',NULL,0,'124241180','Safoura navaie','صفورانوایی','Safura.navaie@gmail.com',0,'2025-11-06 04:19:31.403490','09131148044','2025-11-06 04:19:31.403490','2026-07-03 18:21:29.553910',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.769851'),(32,'pbkdf2_sha256$600000$JdHHuZ0gzeoSkDo5YrIvVI$NtpTMTmg7ArQmAMqYAF1GutDYJRP6a5LlR1hibRsSuA=',NULL,0,'4431184041','Abdolhamid jafari nodushan','عبدالحمید جعفری ندوشن','hamid_nodoshan@yahoo.com',0,'2025-11-06 04:19:31.604168','09131545503','2025-11-06 04:19:31.604168','2026-07-03 18:21:29.558646',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.782113'),(33,'pbkdf2_sha256$600000$fHgYY4EZAUpqfs0hYbcsYy$P0yS6lvN8dXIUXIbBvjD575cwJUhwA09ERrmtDWImV0=',NULL,0,'1671103572','Ali eskandarzade','علی اسکندرزاده','Dreskandarzade@gmail.com',0,'2025-11-06 04:19:31.797643','09124692487','2025-11-06 04:19:31.797643','2026-07-03 18:21:29.563367',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.787995'),(34,'pbkdf2_sha256$600000$TTMCJaaXjtDWF3sYnEPelR$Mp4e7zKv9PdwF8gBX03zq+spB02BhDIpBoQ/jgYY6WA=',NULL,0,'1291138595','Ali Azimi','علی عظيمی','Ali_azimy1349@yahoo.com',0,'2025-11-06 04:19:31.993038','09131616519','2025-11-06 04:19:31.993038','2026-07-03 18:21:29.568381',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.793729'),(35,'pbkdf2_sha256$600000$4yiJyPUDGU7EFr3LwRxOk9$Mc8eaZlUrPKSpyOWJ9tyOLqd21IKi39HwwganTdVrzU=',NULL,0,'1289213895','Alireza daneshibakhtiar','علیرضا دانشی بختیار','Daneshibakhtiar.alireza@gmail.com',0,'2025-11-06 04:19:32.187189','09124938986','2025-11-06 04:19:32.187189','2026-07-03 18:21:29.573614',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.798952'),(36,'pbkdf2_sha256$600000$EcF81fJKXymIiWbVhoBwSP$Serm2xlCf21q/5acstMwQ6a9mNUDoYciqlw4kfy39eg=',NULL,0,'1284980251','ALIREZA ESHGHI','علیرضا عشقی','ali_phd203@yahoo.com',0,'2025-11-06 04:19:32.386717','09124422257','2025-11-06 04:19:32.386717','2026-07-03 18:21:29.578342',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.804302'),(37,'pbkdf2_sha256$600000$EoTHVJr4SrwQj1WkjVgRM5$OBTtb8oSEZDqJjXTDtmNg+TtnSwdYwA5mvK6QZSqYzA=',NULL,0,'0940762651','Alireza Asadi','عليرضا اسدي','asadialireza.dr@gmail.com',0,'2025-11-06 04:19:32.587756','09153090618','2025-11-06 04:19:32.587756','2026-07-03 18:21:29.583152',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.810535'),(38,'pbkdf2_sha256$600000$uoCXOOBzRvIZXZ7tsW3DKm$reUgxaVWBu3yGJKA2v5kjV66cyn+fJOlagP7OWfSIUU=',NULL,0,'4622503646','gholamreza panahandeh shahraki','غلامرضا پناهنده شهركى','gholamrezapanahandeh@gmail.com',0,'2025-11-06 04:19:32.844857','09132828737','2025-11-06 04:19:32.844857','2026-07-03 18:21:29.588605',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.816125'),(39,'pbkdf2_sha256$600000$6OjPv6zAuInRq835RHcxq7$u6jxop50pmMHzvwIcem7slJ+iXVunjKRGJtrc+ggPjI=',NULL,0,'1379169240','Gholamreza Rahbari Banaeian','غلامرضا رهبری بنائیان','Gholamrezarahbari1394@Gmail.com',0,'2025-11-06 04:19:33.176175','09143158828','2025-11-06 04:19:33.176175','2026-07-03 18:21:29.593423',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.822732'),(40,'pbkdf2_sha256$600000$G0xX29ey0tJPn3FfFxK9Xc$ruXr7cJ5TG6E3VAr36YyXfq+tbY+Qrchjgvkda+26jc=',NULL,0,'0074950630','Fatemeh tarighatmonfared','فاطمه طريقت منفردا','Fateme.tarighat@gmail.com',0,'2025-11-06 04:19:33.502018','09122719874','2025-11-06 04:19:33.502018','2026-07-03 18:21:29.612989',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.829404'),(41,'pbkdf2_sha256$600000$BylFroUwvPw2R1VBGLBqvg$g3aCKSLwVg691xBoeR3/ID0eGM6nA6jjgmFkV4hjjEs=',NULL,0,'5010285436','Farzad Masiha','فرزاد مسیحا','dr.masiha_56@yahoo.com',0,'2025-11-06 04:19:33.833130','09129335886','2025-11-06 04:19:33.833130','2026-07-03 18:21:29.617836',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.835618'),(42,'pbkdf2_sha256$600000$d1jrSIvq6A7EsoL87GwLDd$6yQ+rnJPLZ04tdgFoqE3VvBQwxls+M+NNwheucFWCEs=',NULL,0,'137735435','Farinaz amirikar','فریناز امیری کار','Amirikarfarinaz@gmail.com',0,'2025-11-06 04:19:34.159222','9144154387','2025-11-06 04:19:34.159222','2026-07-03 18:21:29.623077',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.842047'),(43,'pbkdf2_sha256$600000$Zpq8ARHKZs1P8o161wW1DO$eAmzHSApwHMymNZVtRNDsKPb9EWiX4jHMFXjLwPVHH8=',NULL,0,'0050139010','Firouz ABDOLLAHI','فیروز عبدالهی','abdff@yahoo.com',0,'2025-11-06 04:19:34.485145','09123004669','2025-11-06 04:19:34.485145','2026-07-03 18:21:29.627996',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.851623'),(44,'pbkdf2_sha256$600000$7vGQau5nV4iA1jb3OpGhCD$KPifK9igtn8vzHdk9tsUICG6boZTG3sui7ZtFONX1J4=',NULL,0,'0045912238','Ghamartaj Khanbabaee','قمرتاج خانبابايي','Khanbabaeegh@yahoo.com',0,'2025-11-06 04:19:34.821616','09121855303','2025-11-06 04:19:34.821616','2026-07-03 18:21:29.632867',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.857467'),(45,'pbkdf2_sha256$600000$fSE8kyoecpXUeMw202GqWp$akHn30XJcVeY5ADBJXWgKKWl+IlL+T4oyvmmsxVwhDQ=',NULL,0,'1376573350','KOROSH FAKHIMI DERAKHSHAN','کوروش فخیمی درخشان','koorosh.fakhimi@gmail.com',0,'2025-11-06 04:19:35.148676','09128039875','2025-11-06 04:19:35.148676','2026-07-03 18:21:29.637613',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.934414'),(46,'pbkdf2_sha256$600000$Z8fdl20Zb3ZFqBVQb1bbkh$BN8FvezWXdwYY9OWVjHrUKWjW1syNaLRJ4oUEX6Sh04=',NULL,0,'0040785696','KEYVAN MALEKI MOSTASHARI','کیوان ملکی مستشاری','KMOSTASHARI@YAHOO.COM',0,'2025-11-06 04:19:35.481466','09352526958','2025-11-06 04:19:35.481466','2026-07-03 18:21:29.642776',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.944743'),(47,'pbkdf2_sha256$600000$DBzYiLHHxmzJ65DnUChTCG$RmuTxUjEkhZVrTGyqJLJqvPzORg+vr4kV5qyc4jT7M4=',NULL,0,'2121450556','Lobat Shahkar','لعبت  شاهكار','Lobatshahkar@yahoo.com',0,'2025-11-06 04:19:35.801098','09111759597','2025-11-06 04:19:35.801098','2026-07-03 18:21:29.647899',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.951179'),(48,'pbkdf2_sha256$600000$QQgOTqEM2MGUw72wTFOl0P$YBNR3PxDrNEyjmYiBZYOXMvAQtRGmzxurUJ0ZKmERV0=','2025-11-06 04:23:42.303465',0,'5179922569','Matin pourghasem','متین پورقاسم','matinpourghasem@yahoo.com',0,'2025-11-06 04:19:36.132658','09111442108','2025-11-06 04:19:36.132658','2026-07-03 18:21:29.652738',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.957118'),(49,'pbkdf2_sha256$600000$mdj94UBpcW3nXCpdtszMWU$1cmx+VjqM3d7wZqfxilhkwwT/7bV2/O3oq70OYlLYMU=',NULL,0,'1288067021','Majid Keivanfar','مجید کیوانفر','Mkeyvanfar@gmail.com',0,'2025-11-06 04:19:36.449453','09121153918','2025-11-06 04:19:36.449453','2026-07-03 18:21:29.657449',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.962492'),(50,'pbkdf2_sha256$600000$z38kQLEeQo9genQff3JqPH$2PTRkyqDB+8XVIagyShYWCQu14DoeBfpAoJ/HwsnUlw=',NULL,0,'181708187','Mohsen   Alisamir','محسن   علی سمیر','mohsensamir90@yahoo.com',0,'2025-11-06 04:19:36.788095','09166160690','2025-11-06 04:19:36.788095','2026-07-03 18:21:29.662414',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.971238'),(51,'pbkdf2_sha256$600000$jhiGru3hrg3vbtDSVswLMJ$GSncmATxvQFM8WRn+I6PngY1J5/2Dpn1SVXWfXev5D0=',NULL,0,'1290420874','Mohsen reisi','محسن رييسي','mohsenreisi72@yahoo.com',0,'2025-11-06 04:19:37.117265','09131061507','2025-11-06 04:19:37.117265','2026-07-03 18:21:29.667167',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.979426'),(52,'pbkdf2_sha256$600000$CM5MIXBhMRuSPwR3rknOJe$fAVTQMOWi55pkHXa5x9fvKCWDwlcnGbjFMfdfhv6pGk=',NULL,0,'2297880960','Mohammad Ashkan Moslehi','محمد اشكان مصلحي','Ashkanmoslehi@gmail.com',0,'2025-11-06 04:19:37.432233','09171177445','2025-11-06 04:19:37.432233','2026-07-03 18:21:29.671954',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.990891'),(53,'pbkdf2_sha256$600000$8hIJPHhohdpXOBujm7b3T9$MiyIdf0PDZqMdFSWxgS/qFwabXa3iwAoNHKCbJ2vn54=',NULL,0,'2529231397','.mohammadreza modaresi','محمد رضا مدرسی','Modaresipul@gmail.com',0,'2025-11-06 04:19:37.771299','09131134710','2025-11-06 04:19:37.771299','2026-07-03 18:21:29.676821',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:25.999600'),(54,'pbkdf2_sha256$600000$ilkmCpwwQiTIQUO9mVxuTl$UmeWyKW6hdwnOFcT8yUsU63qemFKtPaOvWjBDgXzpzc=',NULL,0,'2259703550','Mohammmad Rezaei','محمد رضائی','rezaei.pediatrician@yahoo.com',0,'2025-11-06 04:19:38.096258','09126184837','2025-11-06 04:19:38.096258','2026-07-03 18:21:29.681710',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.008135'),(55,'pbkdf2_sha256$600000$F78LTDnnpV0gE5ZG9BqpWD$MK5DmmHnehmSUNYD4aF3re+tMSTvVa1Lpsy091rVLas=',NULL,0,'2753655693','Mohammad Nanbakhsh','محمد نان بخش','Mohammad_nanbakhsh@yahoo.com',0,'2025-11-06 04:19:38.419841','09144478378','2025-11-06 04:19:38.419841','2026-07-03 18:21:29.686616',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.017590'),(56,'pbkdf2_sha256$600000$cAiWgjZVRXgrWIM5ce7ni8$ciC8UqJcqT4gu6QEZ5X3oFdFvT/4EnrpYe32chjMTDk=',NULL,0,'4322779794','Mohammad Nikpendar','محمد نیک پندار','dr.m.nikpendar@gmail.com',0,'2025-11-06 04:19:38.732761','09123811707','2025-11-06 04:19:38.732761','2026-07-03 18:21:29.691779',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.025888'),(57,'pbkdf2_sha256$600000$SssqoPY5ODyyjfZmC8fSeV$kCIwQVicSV3x5Myr/5d32PiPv5FFheqSCvZjMXppiZ8=',NULL,0,'0061322008','Maryam Hassanzad','مریم حسن زاد','mar_hassanzad@yahoo.com',0,'2025-11-06 04:19:39.070712','09122002452','2025-11-06 04:19:39.070712','2026-07-03 18:21:29.696640',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.052866'),(58,'pbkdf2_sha256$600000$mC0qoc9MR7iRSfk9qcqA0m$v7rjtpDEq+hb+XIoIKW0P7IakZzcInrxMBon5vNLNTk=',NULL,0,'2161807277','Masoud kiani','مسعود کیانی','kianimasood@yahoo.com',0,'2025-11-06 04:19:39.399655','09113264997','2025-11-06 04:19:39.399655','2026-07-03 18:21:29.701485',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.058807'),(59,'pbkdf2_sha256$600000$Z5aq5n3dpJTn0VJq0i09gF$j14bkOaXG7YlWM5hVmTEWR1R8ZlR8KDwulgcx2NSPvU=',NULL,0,'1582254516','Masoumeh ghasempouralamdari','معصومه قاسمپور علمداری','Masoumeh_gh_a@yahoo.com',0,'2025-11-06 04:19:39.727527','9144910663','2025-11-06 04:19:39.727527','2026-07-03 18:21:29.706413',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.064354'),(60,'pbkdf2_sha256$600000$0t015b0FPPUL2gvPbl15wU$pRzmW+EZ+BVC180EODvdusUYjBNg6Bbems5zDYspMkA=',NULL,0,'71579470','Mahdieh ghaempanah','مهدیه قائم پناه','Mah.ghaempanah@gmail.com',0,'2025-11-06 04:19:40.055629','09123453395','2025-11-06 04:19:40.055629','2026-07-03 18:21:29.711284',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.074601'),(61,'pbkdf2_sha256$600000$xLKWPl7pE3sdib2uZGfS2n$mBZNV41EG3P6eoOjuKCxKR9x2nT9c3WEczsRbZPhVmA=',NULL,0,'2300325608','Nazanin Farahbakhsh','نازنین فرح بخش','nazanin26farahbakhsh@yahoo.com',0,'2025-11-06 04:19:40.379887','09173174115','2025-11-06 04:19:40.379887','2026-07-03 18:21:29.716305',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.092503'),(62,'pbkdf2_sha256$600000$oIsOTyugmnideNXdstjzf5$WzVar/LLTUvv0pBJN4q9Q87bl9ODB1ior18S/HJS+w0=',NULL,0,'1285704436','Nasrin Hoseiny Nejad','نسرین حسینی نژاد','nasrnejad@gmail.com',0,'2025-11-06 04:19:40.691881','09123377175','2025-11-06 04:19:40.691881','2026-07-03 18:21:29.721139',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.102162'),(63,'pbkdf2_sha256$600000$FpIEuijAWjqeeOEJFqwb2F$8XuqlfXFURYlZwUWfh87pBw9uMfN7Z6QDodlz0jwFVk=',NULL,0,'3873302616','Nooshin.Baghaie','نوشين بقايي.','nbbaghaie@yahoo.com',0,'2025-11-06 04:19:41.041528','09121305042','2025-11-06 04:19:41.041528','2026-07-03 18:21:29.726092',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.113329'),(64,'pbkdf2_sha256$600000$pEHHmXhaSWQLGBMUm2jimR$xW66RGUw1mgPJXuMW/Y/5c1qhVMFOp5+tn2g9FQYHLE=','2025-11-14 10:40:20.388310',0,'4432837179','Seyedehzalfa Modarresi','ذلفا مدرسی','dr.modarress@gmail.com',0,'2025-11-06 04:19:41.356707','9133517476','2025-11-06 04:19:41.356707','2026-07-03 18:21:29.733620',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.121356'),(65,'pbkdf2_sha256$600000$3mlk692cfhb90je0TWU30A$Isv+1Mw4JwXTtVJuKCCqgQMCbi9wQFmjuSM04UwJxSI=',NULL,0,'79934196','أNasrin jalalimanesh','نسرین جلالی منش','',0,'2025-11-06 04:19:41.703711','9120341926','2025-11-06 04:19:41.703711','2026-07-03 18:21:29.738872',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.128077'),(66,'pbkdf2_sha256$600000$ZKY9omyp2AcIELzxZ4DR6R$Eg6kLVKVvzPQN6SwCyqzuIw0Ta2v06fJZeFjM5A4ak8=',NULL,0,'2200762917','','فاطمه خزائی کوه پر','',0,'2025-11-06 04:19:42.033159','9125251319','2025-11-06 04:19:42.033159','2026-07-03 18:21:29.744045',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.143225'),(67,'pbkdf2_sha256$600000$lZiKM1UTIUCBh96FSBUow8$7XlEeivIIMUd/TssLfHCdFVRrYKXVFtn4J1VeaJhPbU=',NULL,0,'1757893709','','نرگس خزائی','khazaeenarges2017@gmail.com',0,'2025-11-06 04:19:42.351873','9132051279','2025-11-06 04:19:42.351873','2026-07-03 18:21:29.748951',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.210760'),(68,'pbkdf2_sha256$600000$HgwnjbISEnuABLAIhZqETP$GPEHrRNNjG31aHBDJ0wwP4NjyAk0WZKoFGajo3BeQTw=',NULL,0,'1850093751','ahmad safapour','احمد صفاپور','ahmad.safapour@gmail.com',0,'2025-11-06 04:19:42.687174','9163726098','2025-11-06 04:19:42.687174','2026-07-03 18:21:29.753824',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.217211'),(69,'pbkdf2_sha256$600000$iMGNOPx6AqyqSMuX7oHNiZ$Gb2b7eTv5psoirL/JwK+QTnlz6b1cUuCvKgowmEs2xw=',NULL,0,'1376866676','Elina EivazzadehKeyhan','الینا عیوض زاده کیهان','el.eyvazzade@gmail.com',0,'2025-11-06 04:19:43.006288','9146454938','2025-11-06 04:19:43.006288','2026-07-03 18:21:29.758894',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.230890'),(70,'pbkdf2_sha256$600000$suIiDA0TfVhIb9Jus7IS5K$mTC6HeqltWH0z5byguDo+hxGOfzhz9weDa6vzJMnUPA=',NULL,0,'2064701214','Zahra Pourramzan','زهرا پوررمضان','Z.pourramzan@gmail.com',0,'2025-11-06 04:19:43.341857','9111140488','2025-11-06 04:19:43.341857','2026-07-03 18:21:29.763975',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.238038'),(71,'pbkdf2_sha256$600000$p4sAIeWmKkTNrLIPEVvZR8$LcM6DW0d0ZBwatCiVXikS4xWzLVGK7Gp8IcSZjkSXDs=',NULL,0,'1361164298','Maedeh Gheibi','مائده  غیبی','Mghfar21@gmail.com',0,'2025-11-06 04:19:43.666484','9384048542','2025-11-06 04:19:43.666484','2026-07-03 18:21:29.768861',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.243983'),(72,'pbkdf2_sha256$600000$TWa8NPh0jQHH5e60mhXQzw$Mw+z+xdc0FaPilnEqlFggT3xdVoi/T+joSSFRJXAe3o=',NULL,0,'1850185131','Abdolhamid Taghizadeh Behbahani','عبدالحمید تقی زاده بهبهانی','Hamidt1000@gmail.com',0,'2025-11-06 04:19:43.989453','9178979629','2025-11-06 04:19:43.990490','2026-07-03 18:21:29.773800',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.249405'),(73,'pbkdf2_sha256$600000$0A96bFjPZaWU8xDqr8Ygaj$/YH0XONYiViRAzwGoL9kQUgugQkkkMUptp6RhIvtDsw=',NULL,0,'2064696458','Narges Keshvarparast','نرگس  کشورپرست','Khatere.137784@gmail.com',0,'2025-11-06 04:19:44.305843','9377691054','2025-11-06 04:19:44.305843','2026-07-03 18:21:29.778384',1,'','',0,0.0,'','','','','','','','','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.255090'),(74,'pbkdf2_sha256$600000$e941IMswvnKQiLK6LuKV0F$E4Ltr5YKhYbCq/4omTTvzocBwANVNHv/JNyganXxX5A=',NULL,0,'dr_ahmadi','احمد','احمدی','dr.ahmadi@ispp.ir',0,'2025-11-13 11:27:48.030041','09121234567','2025-11-13 11:27:48.031447','2026-07-03 18:21:29.783458',1,'دکتر احمد احمدی متخصص ریه کودکان با بیش از 15 سال تجربه در تشخیص و درمان بیماری‌های تنفسی کودکان است. وی فارغ‌التحصیل دانشگاه علوم پزشکی تهران و دارای بورد تخصصی ریه کودکان می‌باشد.','تهران',15,4.8,'متخصص ریه کودکان','','جایزه بهترین پژوهشگر سال 1400 انجمن ریه کودکان\nتقدیرنامه از وزارت بهداشت برای خدمات برجسته','گواهینامه بین‌المللی طب اطفال\nگواهینامه تخصصی ریه کودکان از انجمن اروپایی','دکترای پزشکی - دانشگاه علوم پزشکی تهران\nتخصص ریه کودکان - بیمارستان کودکان مفید','فارسی، انگلیسی، عربی','بیش از 25 مقاله علمی در زمینه بیماری‌های ریوی کودکان\nنویسنده کتاب \"راهنمای تشخیص آسم کودکان\"','آسم کودکان، بیماری‌های مزمن ریوی، آلرژی تنفسی','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.261271'),(75,'pbkdf2_sha256$600000$VmZs2mdQtvj7NeFES37Jwo$eBvuWMn7+Tey3xR6FMjJte38ZOXNVyqwFma37nB9qr4=',NULL,0,'dr_karimi','فاطمه','کریمی','dr.karimi@ispp.ir',0,'2025-11-13 11:27:48.269464','09129876543','2025-11-13 11:27:48.269464','2026-07-03 18:21:29.788651',1,'دکتر فاطمه کریمی فوق تخصص ریه کودکان و یکی از اعضای برجسته انجمن علمی ریه کودکان ایران است. تخصص ویژه وی در زمینه درمان آسم شدید کودکان و بیماری‌های نادر ریوی می‌باشد.','اصفهان',12,4.9,'فوق تخصص ریه کودکان','','جایزه ملی تحقیقات پزشکی 1399\nنشان عالی خدمات پزشکی از رئیس جمهور','عضو انجمن بین‌المللی ریه کودکان\nگواهینامه تخصصی از دانشگاه هاروارد','دکترای پزشکی - دانشگاه علوم پزشکی اصفهان\nفوق تخصص ریه کودکان - بیمارستان کودکان علی اصغر','فارسی، انگلیسی، فرانسوی','نویسنده بیش از 30 مقاله در مجلات معتبر بین‌المللی\nسردبیر مجله ریه کودکان ایران','بیماری‌های نادر ریوی، ژن درمانی، طب شخصی‌سازی شده','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.266879'),(76,'pbkdf2_sha256$600000$Rqf6AJWGvmF2LF6gg53glO$s4wJurThHTBVis0tBfuAxik/gBIBc1jTzBWCr37F3Nw=',NULL,0,'dr_hosseini','محمد','حسینی','dr.hosseini@ispp.ir',0,'2025-11-13 11:27:48.486365','09135551234','2025-11-13 11:27:48.486365','2026-07-03 18:21:29.793567',1,'دکتر محمد حسینی با بیش از 18 سال تجربه در زمینه طب اطفال و ریه کودکان، یکی از پیشگامان در استفاده از روش‌های نوین درمانی در شرق کشور محسوب می‌شود.','مشهد',18,4.7,'متخصص اطفال و ریه کودکان','','استاد نمونه دانشگاه علوم پزشکی مشهد\nجایزه انجمن پزشکان ایران برای نوآوری در درمان','گواهینامه بین‌المللی اولتراسونوگرافی ریه\nمدرک تخصصی طب اورژانس کودکان','دکترای پزشکی - دانشگاه علوم پزشکی مشهد\nتخصص اطفال و فوق تخصص ریه کودکان','فارسی، انگلیسی، عربی','نویسنده 20 مقاله علمی و 3 کتاب تخصصی\nمترجم کتاب \"اصول ریه کودکان نلسون\"','اولتراسونوگرافی ریه، طب اورژانس تنفسی، تله‌مدیسین','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.272859'),(77,'pbkdf2_sha256$600000$qESFUCLpIPcL6do3mzslqx$aTuTn6OPJbtwEQ3nD8qVznpgOqZVU/mnSZXSGPWLV+k=',NULL,0,'dr_moradi','زهرا','مرادی','dr.moradi@ispp.ir',0,'2025-11-13 11:27:48.700030','09177778888','2025-11-13 11:27:48.700030','2026-07-03 18:21:29.798616',1,'دکتر زهرا مرادی متخصص آلرژی و ایمونولوژی کودکان است که تخصص ویژه‌ای در زمینه تشخیص و درمان آلرژی‌های تنفسی و آسم کودکان دارد. وی عضو فعال انجمن آلرژی ایران نیز می‌باشد.','شیراز',10,4.6,'متخصص آلرژی و ایمونولوژی کودکان','','جایزه بهترین پژوهش بالینی انجمن آلرژی ایران\nتقدیرنامه از دانشگاه علوم پزشکی شیراز','گواهینامه بین‌المللی تست‌های آلرژی\nمدرک تخصصی ایمونوتراپی از اروپا','دکترای پزشکی - دانشگاه علوم پزشکی شیراز\nفوق تخصص آلرژی و ایمونولوژی کودکان - بیمارستان نمازی','فارسی، انگلیسی','نویسنده 15 مقاله در زمینه آلرژی کودکان\nهمکار در تألیف \"راهنمای آلرژی کودکان ایران\"','آلرژی غذایی، ایمونوتراپی، آسم شدید کودکان','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.283013'),(78,'pbkdf2_sha256$600000$CWGgwIL1TilViWgEQQ6otW$jY0hzYZY9BxUeRpxHqe0mIUUFqJ5PbZSJn5Vcruh1NE=',NULL,0,'dr_rezaei','علی','رضایی','dr.rezaei@ispp.ir',0,'2025-11-13 11:27:48.919106','09194445555','2025-11-13 11:27:48.919106','2026-07-03 18:21:29.803680',1,'دکتر علی رضایی جوان‌ترین عضو هیئت علمی انجمن ریه کودکان است که تخصص نوینی در زمینه اختلالات خواب مرتبط با تنفس در کودکان دارد. وی پیشگام استفاده از فناوری‌های نوین در تشخیص است.','تبریز',8,4.5,'متخصص ریه کودکان و طب خواب','','جایزه بهترین پژوهشگر جوان انجمن ریه کودکان\nبورسیه تحقیقاتی از دانشگاه استنفورد','گواهینامه بین‌المللی طب خواب\nمدرک تخصصی پلی‌سومنوگرافی کودکان','دکترای پزشکی - دانشگاه علوم پزشکی تبریز\nفلوشیپ طب خواب کودکان - بیمارستان کودکان تهران','فارسی، انگلیسی، ترکی آذربایجانی','نویسنده 12 مقاله در زمینه طب خواب کودکان\nمقالات متعدد در مجلات بین‌المللی','اختلالات خواب تنفسی، آپنه خواب کودکان، فناوری‌های تشخیصی نوین','pending',NULL,NULL,NULL,'2026-07-03 17:05:26.288985'),(79,'!Pq2kmXUP9W4jYudjb7UYSyLzDr2PCSuaZwdQMGIO',NULL,0,'board_سهیلا_خلیل_زاده','دکتر سهیلا خلیل زاده','Dr. Soheila Khalilzadeh','',0,'2026-07-03 17:05:26.559124',NULL,'2026-07-03 17:05:26.573528','2026-07-03 18:21:30.184319',1,'نائب رئیس - دوره 1403',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:26.560884'),(80,'!u4ykGTEiMst5ZT2SNpi9JAci5oRSV0hj0gzYOLR6',NULL,0,'board_قرم_تاج_خان_بابایی','دکتر قرم تاج خان بابایی','Dr. Ghamar Taj Khanbabai','',0,'2026-07-03 17:05:26.999908',NULL,'2026-07-03 17:05:27.004781','2026-07-03 18:21:30.174294',1,'رئیس انجمن - دوره 1403',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.000998'),(81,'!RxAbhL7Bup6ip6v8M0smkemV0mwIPJf5C0Klx9Nd',NULL,0,'board_محمد_رضائی','دکتر محمد رضائی','Dr. Mohammad Rezaei','',0,'2026-07-03 17:05:27.102602',NULL,'2026-07-03 17:05:27.104626','2026-07-03 18:21:30.189403',1,'دبیر انجمن - دوره 1403',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.102943'),(82,'!uJUc9xwwF2BeiV9hOr1ngxMZKEAOR0pmVMSWVkt8',NULL,0,'board_مجید_کیوانفر','دکتر مجید کیوانفر','Dr. Majid Keyvanfar','',0,'2026-07-03 17:05:27.113371',NULL,'2026-07-03 17:05:27.113814','2026-07-03 18:21:30.136582',1,'رئیس انجمن - دوره 1400',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.113426'),(83,'!A3MBIZCosLD97u1fMZyfdVW3uKLWG2dqhJnd0I88',NULL,0,'board_سید_احمد_طباطبائی','دکتر سید احمد طباطبائی','Dr. Seyed Ahmad Tabatabaei','',0,'2026-07-03 17:05:27.120380',NULL,'2026-07-03 17:05:27.120834','2026-07-03 18:21:30.103648',1,'عضو هیئت مدیره - دوره 1395',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.120411'),(84,'!AtbfnYUFtUq51Xz9ayDVMpn9RXLbChEdCZ8KFMdd',NULL,0,'board_محسن_علی_سمیر','دکتر محسن علی سمیر','Dr. Mohsen Ali Samir','',0,'2026-07-03 17:05:27.127346',NULL,'2026-07-03 17:05:27.127793','2026-07-03 18:21:30.108339',1,'عضو هیئت مدیره - دوره 1395',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.127457'),(85,'!v25Ux1NSDw1JYVt7iVpr7WA7xx04rFI4HSffz3ox',NULL,0,'board_حسینعلی_غفاری_پور','دکتر حسینعلی غفاری پور','Dr. Hosseinali Ghaffaripour','',0,'2026-07-03 17:05:27.134952',NULL,'2026-07-03 17:05:27.135336','2026-07-03 18:21:30.112902',1,'عضو هیئت مدیره - دوره 1395',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.134984'),(86,'!glfR5svabVzoJ0YdvzIw6cipU3suIgyo9kTW6PKJ',NULL,0,'board_محمد_رضا_مدرسی','دکتر محمد رضا مدرسی','Dr. Mohammad Reza Modarresi','',0,'2026-07-03 17:05:27.141912',NULL,'2026-07-03 17:05:27.142358','2026-07-03 18:21:30.117509',1,'عضو هیئت مدیره علی البدل - دوره 1395',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.141964'),(87,'!Pwf717THSJreYKfGcXAoxlDblCm637Bmhpmskpq6',NULL,0,'board_سید_جواد_سیدی','دکتر سید جواد سیدی','Dr. Seyed Javad Seyedi','',0,'2026-07-03 17:05:27.149365',NULL,'2026-07-03 17:05:27.149764','2026-07-03 18:21:30.122231',1,'عضو هیئت مدیره علی البدل - دوره 1395',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.149400'),(88,'!zYv511U2x34EZ7zqwFktQk7gubugwFKdaMGVbP3K',NULL,0,'board_روح_الله_شیرزادی','دکتر روح الله شیرزادی','Dr. Rouhollah Shirzadi','',0,'2026-07-03 17:05:27.156503',NULL,'2026-07-03 17:05:27.156870','2026-07-03 18:21:30.126962',1,'بازرس اصلی - دوره 1395',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.156539'),(89,'!G8v6BdtQ9r2BKkzgicG1m7OtxFovDytAeWYYXFf0',NULL,0,'board_علیرضا_اسدی','دکتر علیرضا اسدی','Dr. Alireza Asadi','',0,'2026-07-03 17:05:27.163791',NULL,'2026-07-03 17:05:27.164218','2026-07-03 18:21:30.131692',1,'بازرس علی البدل - دوره 1395',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.163825'),(90,'!cCr8dmJknw7d7uOSrjMJgCIoupBy1I87vE3DnAng',NULL,0,'board_امیر_رضائی','دکتر امیر رضائی','Dr. Amir Rezaei','',0,'2026-07-03 17:05:27.182057',NULL,'2026-07-03 17:05:27.182451','2026-07-03 18:21:30.198897',1,'عضو هیئت مدیره - دوره 1403',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.182089'),(91,'!VPsHNQ9LclVl7R83pZphsd47iHaLlEBB5PIcRuTA',NULL,0,'board_علیرضا_عشقی','دکتر علیرضا عشقی','Dr. Alireza Eshghi','',0,'2026-07-03 17:05:27.188719',NULL,'2026-07-03 17:05:27.189054','2026-07-03 18:21:30.207963',1,'عضو هیئت مدیره - دوره 1403',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.188751'),(92,'!JNiVz5bZydvNPo09KEhvVNCnh2SLF2ABA3LJwMip',NULL,0,'board_سید_محمد_رضا_میرکریمی','دکتر سید محمد رضا میرکریمی','Dr. Seyed Mohammad Reza Mirkarimi','',0,'2026-07-03 17:05:27.198985',NULL,'2026-07-03 17:05:27.199446','2026-07-03 18:21:30.155546',1,'عضو هیئت مدیره - دوره 1400',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.199019'),(93,'!fRNOTHbiKRpHx7IHLD1XlErNczb2aLiDY75U5D8o',NULL,0,'board_بابک_قالیباف','دکتر بابک قالیباف','Dr. Babak Ghalibaf','',0,'2026-07-03 17:05:27.206139',NULL,'2026-07-03 17:05:27.206542','2026-07-03 18:21:30.160031',1,'عضو هیئت مدیره - دوره 1400',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.206171'),(94,'!IY2tkdimEAKvCytT7IntlZvyJtnqw38U6S5zgOlt',NULL,0,'board_سید_حسین_میر_لوحی','دکتر سید حسین میر لوحی','Dr. Seyed Hossein Mirlouhi','',0,'2026-07-03 17:05:27.214044',NULL,'2026-07-03 17:05:27.214416','2026-07-03 18:21:30.164919',1,'عضو هیئت مدیره - دوره 1400',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.214075'),(95,'!3OalFVrbwHXUydYbA4rLlOdjbqCEQ9XQnn5mo8fE',NULL,0,'board_لعبت_شاهکار','دکتر لعبت شاهکار','Dr. Lobat Shahkar','',0,'2026-07-03 17:05:27.222239',NULL,'2026-07-03 17:05:27.222823','2026-07-03 18:21:30.169622',1,'بازرس اصلی - دوره 1400',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.222270'),(96,'!ddVdY7xto9zWTReGY4ys3FH37beinp1dA5jBygz7',NULL,0,'board_نازنین_فرحبخش','دکتر نازنین فرحبخش','Dr. Nazanin Farahbakhsh','',0,'2026-07-03 17:05:27.246839',NULL,'2026-07-03 17:05:27.247223','2026-07-03 18:21:30.194121',1,'خزانه دار - دوره 1403',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.246872'),(97,'!LTmewOEGLaJ6BARe89lHT1jrz8ZcNIcynAUvFt1m',NULL,0,'board_ذلفا_مدرسی','دکتر ذلفا مدرسی','Dr. Zolfa Modarresi','',0,'2026-07-03 17:05:27.260101',NULL,'2026-07-03 17:05:27.260684','2026-07-03 18:21:30.203193',1,'عضو هیئت مدیره - دوره 1403',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.260133'),(98,'!qc0bzE5qGJpJYNaETqYgPFycVdkqIwT4YGYGFSJl',NULL,0,'board_معصومه_قاسمپور_علمداری','دکتر معصومه قاسمپور علمداری','Dr. Masoumeh Ghasempour Alamdari','',0,'2026-07-03 17:05:27.273411',NULL,'2026-07-03 17:05:27.274013','2026-07-03 18:21:30.212619',1,'بازرس اصلی - دوره 1403',NULL,0,0.0,'فوق تخصص ریه کودکان','',NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,'2026-07-03 17:05:27.273441');
/*!40000 ALTER TABLE `accounts_customuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_customuser_groups`
--

DROP TABLE IF EXISTS `accounts_customuser_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_customuser_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `customuser_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_customuser_groups_customuser_id_group_id_c074bdcb_uniq` (`customuser_id`,`group_id`),
  KEY `accounts_customuser_groups_group_id_86ba5f9e_fk_auth_group_id` (`group_id`),
  CONSTRAINT `accounts_customuser__customuser_id_bc55088e_fk_accounts_` FOREIGN KEY (`customuser_id`) REFERENCES `accounts_customuser` (`id`),
  CONSTRAINT `accounts_customuser_groups_group_id_86ba5f9e_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_customuser_groups`
--

LOCK TABLES `accounts_customuser_groups` WRITE;
/*!40000 ALTER TABLE `accounts_customuser_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_customuser_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_customuser_user_permissions`
--

DROP TABLE IF EXISTS `accounts_customuser_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_customuser_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `customuser_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_customuser_user_customuser_id_permission_9632a709_uniq` (`customuser_id`,`permission_id`),
  KEY `accounts_customuser__permission_id_aea3d0e5_fk_auth_perm` (`permission_id`),
  CONSTRAINT `accounts_customuser__customuser_id_0deaefae_fk_accounts_` FOREIGN KEY (`customuser_id`) REFERENCES `accounts_customuser` (`id`),
  CONSTRAINT `accounts_customuser__permission_id_aea3d0e5_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_customuser_user_permissions`
--

LOCK TABLES `accounts_customuser_user_permissions` WRITE;
/*!40000 ALTER TABLE `accounts_customuser_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_customuser_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add کاربر',6,'add_customuser'),(22,'Can change کاربر',6,'change_customuser'),(23,'Can delete کاربر',6,'delete_customuser'),(24,'Can view کاربر',6,'view_customuser'),(25,'Can add خبر',7,'add_news'),(26,'Can change خبر',7,'change_news'),(27,'Can delete خبر',7,'delete_news'),(28,'Can view خبر',7,'view_news'),(29,'Can add اطلاعیه',8,'add_announcement'),(30,'Can change اطلاعیه',8,'change_announcement'),(31,'Can delete اطلاعیه',8,'delete_announcement'),(32,'Can view اطلاعیه',8,'view_announcement'),(33,'Can add رویداد',9,'add_event'),(34,'Can change رویداد',9,'change_event'),(35,'Can delete رویداد',9,'delete_event'),(36,'Can view رویداد',9,'view_event'),(37,'Can add ثبت نام رویداد',10,'add_eventregistration'),(38,'Can change ثبت نام رویداد',10,'change_eventregistration'),(39,'Can delete ثبت نام رویداد',10,'delete_eventregistration'),(40,'Can view ثبت نام رویداد',10,'view_eventregistration');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext COLLATE utf8mb4_unicode_ci,
  `object_repr` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_accounts_customuser_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_accounts_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `accounts_customuser` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (6,'accounts','customuser'),(1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'contenttypes','contenttype'),(9,'events','event'),(10,'events','eventregistration'),(8,'news','announcement'),(7,'news','news'),(5,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2026-06-23 10:15:28.478786'),(2,'contenttypes','0002_remove_content_type_name','2026-06-23 10:15:28.570062'),(3,'auth','0001_initial','2026-06-23 10:15:28.834273'),(4,'auth','0002_alter_permission_name_max_length','2026-06-23 10:15:28.885584'),(5,'auth','0003_alter_user_email_max_length','2026-06-23 10:15:28.899157'),(6,'auth','0004_alter_user_username_opts','2026-06-23 10:15:28.909593'),(7,'auth','0005_alter_user_last_login_null','2026-06-23 10:15:28.918853'),(8,'auth','0006_require_contenttypes_0002','2026-06-23 10:15:28.922845'),(9,'auth','0007_alter_validators_add_error_messages','2026-06-23 10:15:28.932223'),(10,'auth','0008_alter_user_username_max_length','2026-06-23 10:15:28.941718'),(11,'auth','0009_alter_user_last_name_max_length','2026-06-23 10:15:28.950816'),(12,'auth','0010_alter_group_name_max_length','2026-06-23 10:15:28.969916'),(13,'auth','0011_update_proxy_permissions','2026-06-23 10:15:28.981955'),(14,'auth','0012_alter_user_first_name_max_length','2026-06-23 10:15:28.991820'),(15,'accounts','0001_initial','2026-06-23 10:15:29.238089'),(16,'accounts','0002_customuser_bio_customuser_city_customuser_experience_and_more','2026-06-23 10:15:29.445243'),(17,'accounts','0003_customuser_first_name_fa_customuser_last_name_fa','2026-06-23 10:15:29.519088'),(18,'accounts','0004_customuser_profile_image','2026-06-23 10:15:29.559771'),(19,'accounts','0005_customuser_awards_customuser_certifications_and_more','2026-06-23 10:15:29.784357'),(20,'accounts','0006_remove_customuser_first_name_fa_and_more','2026-06-23 10:15:29.928162'),(21,'accounts','0007_customuser_approval_status_customuser_approved_at_and_more','2026-06-23 10:15:30.218497'),(22,'admin','0001_initial','2026-06-23 10:15:30.342746'),(23,'admin','0002_logentry_remove_auto_add','2026-06-23 10:15:30.356660'),(24,'admin','0003_logentry_add_action_flag_choices','2026-06-23 10:15:30.369902'),(25,'events','0001_initial','2026-06-23 10:15:30.678245'),(26,'events','0002_event_agenda_event_contact_info_event_cover_image_and_more','2026-06-23 10:15:31.329561'),(27,'events','0003_alter_event_options_remove_event_end_date_and_more','2026-06-23 10:15:31.487502'),(28,'events','0004_event_retraining_number_alter_event_event_type','2026-06-23 10:15:31.554118'),(29,'news','0001_initial','2026-06-23 10:15:31.712471'),(30,'news','0002_news_category_news_short_content_news_source_and_more','2026-06-23 10:15:31.902028'),(31,'sessions','0001_initial','2026-06-23 10:15:31.934488');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('d35c4hvh98obbszkjzvtqbkf22sbnjjv','.eJxVjEEKwyAURO_iukiMGrXL7nMG-fq_NW1RiMmq9O41kEULAwPzZubNPOxb9nuj1S_Irkywy28WID6pHAAfUO6Vx1q2dQn8qPCTNj5XpNft7P4dZGi5r6PRmowTgeyokFSUQgIo7J4UjpMQCiY7aEhgKULoAudckm5AaVCwzxfyVTiG:1wfitv:HkUupo8bF9Qf_qn4hLc3NKOTSgPbB9bdncqs8LamasI','2026-07-04 18:46:11.279303');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events_event`
--

DROP TABLE IF EXISTS `events_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events_event` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registration_deadline` date DEFAULT NULL,
  `max_participants` int DEFAULT NULL,
  `price` decimal(10,0) NOT NULL,
  `is_published` tinyint(1) NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `views` int NOT NULL,
  `created_by_id` bigint NOT NULL,
  `agenda` longtext COLLATE utf8mb4_unicode_ci,
  `contact_info` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cover_image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_month` int DEFAULT NULL,
  `event_year` int DEFAULT NULL,
  `organizer` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prerequisites` longtext COLLATE utf8mb4_unicode_ci,
  `short_description` longtext COLLATE utf8mb4_unicode_ci,
  `speakers` longtext COLLATE utf8mb4_unicode_ci,
  `target_audience` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `retraining_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `events_event_created_by_id_2c28ea90_fk_accounts_customuser_id` (`created_by_id`),
  CONSTRAINT `events_event_created_by_id_2c28ea90_fk_accounts_customuser_id` FOREIGN KEY (`created_by_id`) REFERENCES `accounts_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events_event`
--

LOCK TABLES `events_event` WRITE;
/*!40000 ALTER TABLE `events_event` DISABLE KEYS */;
INSERT INTO `events_event` VALUES (1,'پنجمین همایش سالیانه انجمن علمی ریه کودکان ایران','panjomin-hamayesh-saliane-1403','انجمن علمی ریه کودکان ایران با افتخار برگزاری پنجمین همایش سالیانه خود را اعلام می‌کند.\n\nاین همایش در تاریخ ۳۱ خرداد و ۱ تیر ۱۴۰۳ در بیمارستان کودکان مفید تهران برگزار می‌گردد.\n\n**محورهای اصلی همایش:**\n\n**روز اول - پنجشنبه ۳۱ خرداد ۱۴۰۳:**\n\n**پنل اول: سرفه در کودکان**\nگردانندگان پنل: دکتر امیرحسین جعفری روحی، دکتر روح‌الله شیرزادی، دکتر سعید صدر، دکتر صدیقه یوسف‌زادگان\n\n- ۰۸:۳۰ - ۰۸:۱۵: کلیات و مکانیسم سرفه - دکتر محمد نیک‌پندار\n- ۰۸:۵۰ - ۰۸:۳۰: علل و درمان سرفه حاد در کودکان - دکتر علیرضا عشقی\n- ۰۹:۱۰ - ۰۸:۵۰: علل و درمان سرفه مزمن در کودکان - دکتر سیدحسین میرلوحی\n- ۰۹:۳۰ - ۰۹:۱۰: علل و درمان سرفه non-stop در کودکان - دکتر امیرحسین جعفری روحی\n- ۰۹:۵۰ - ۰۹:۳۰: درمان‌های خانگی و راهکارهای غیر دارویی در سرفه - دکتر سعید صدر\n- ۱۰:۱۰ - ۰۹:۵۰: ضد سرفه‌ها و کاربرد آن در بیماری‌های ریوی کودکان - دکتر مهدی علیزاده\n- ۱۰:۳۰ - ۱۰:۱۰: ضد احتقان‌ها و کاربرد آن در بیماری‌های ریوی کودکان - دکتر نفیسه فدوی\n\n**پنل دوم: آئروسل تراپی**\nگردانندگان پنل: دکتر مریم حسن‌زاد، دکتر آذر دسترنجی، دکتر محمد رضائی، دکتر محمد نیک‌پندار\n\n- ۱۱:۲۰ - ۱۱:۰۰: کلیات و مکانیسم آئروسل تراپی - دکتر محمد رضائی\n- ۱۱:۳۵ - ۱۱:۲۰: بتا میتونیک‌های استنشاقی - دکتر نرگس کشورپرست\n- ۱۱:۵۰ - ۱۱:۳۵: کورتیکواستروئیدهای استنشاقی - دکتر ذلفا مدرسی\n- ۱۲:۰۵ - ۱۱:۵۰: موکولیتیک‌های استنشاقی - دکتر مریم حسن‌زاد\n- ۱۲:۲۰ - ۱۲:۰۵: آنتی‌بیوتیک‌های استنشاقی - دکتر متین پورقاسم\n- ۱۲:۳۵ - ۱۲:۲۰: سایر داروهای استنشاقی نوظهور - دکتر صدیقه یوسف‌زادگان\n\n**پنل سوم: سیستیک فیبروزیس**\nگردانندگان پنل: دکتر قمرتاج خانبابایی، دکتر سهیلا خلیل‌زاده، دکتر سیدجواد سیدی، دکتر محمدرضا مدرسی\n\n- ۱۳:۵۰ - ۱۳:۳۰: تشخیص و غربالگری سیستیک فیبروزیس - دکتر سهیلا خلیل‌زاده\n- ۱۴:۱۰ - ۱۳:۵۰: درمان مشکلات ریوی در سیستیک فیبروزیس - دکتر قمرتاج خانبابایی\n- ۱۴:۳۰ - ۱۴:۱۰: نحوه مدیریت بیماران CF پس از سن کودکی - دکتر حسینعلی غفاری‌پور\n- ۱۴:۵۰ - ۱۴:۳۰: پایش بیماران سیستیک فیبروزیس - دکتر محمدرضا مدرسی\n\n**پنل چهارم: مداخلات تشخیصی در بیماری‌های ریوی کودکان**\nگردانندگان پنل: دکتر عبدالحمید جعفری ندوشن، دکتر میترا خلیلی، دکتر شیلا محمدی، دکتر سعید هاشمی\n\n- ۱۵:۱۵ - ۱۵:۰۰: اسپیرومتری و کاربرد آن - دکتر شیلا محمدی\n- ۱۵:۳۰ - ۱۵:۱۵: برونکوسکوپی و کاربرد آن - دکتر فاطمه طریقت منفرد\n- ۱۵:۴۵ - ۱۵:۳۰: سونوگرافی ریه و کاربرد آن - دکتر میترا خلیلی\n- ۱۶:۰۰ - ۱۵:۴۵: گرافی ساده قفسه سینه و کاربرد آن - دکتر عبدالحمید جعفری ندوشن\n- ۱۶:۱۵ - ۱۶:۰۰: سی‌تی اسکن ریه و کاربرد آن - دکتر معصومه قاسمپور\n- ۱۶:۳۰ - ۱۶:۱۵: ام‌آرآی و کاربرد آن - دکتر زهرا قمی\n\n**روز دوم - جمعه ۱ تیر ۱۴۰۳:**\n\n**پنل اول: برخورد با ویزینگ در کودکان**\nگردانندگان پنل: دکتر سیداحمد طباطبایی، دکتر نازنین فرحبخش، دکتر مجید کیوانفر، دکتر سیدحسین میرلوحی\n\n- ۰۸:۲۰ - ۰۸:۰۰: کلیات و مکانیسم ویزینگ - دکتر سیداحمد طباطبائی\n- ۰۸:۴۰ - ۰۸:۲۰: علل شایع ویز در کودکان - دکتر سارا قهرمانی\n- ۰۹:۰۰ - ۰۸:۴۰: بررسی‌های تشخیصی در ویزینگ - دکتر مجید کیوانفر\n- ۰۹:۱۵ - ۰۹:۰۰: نقش استروئیدها در ویزینگ - دکتر روح‌الله شیرزادی\n- ۰۹:۳۰ - ۰۹:۱۵: نقش برونکودیلاتورها در ویزینگ - دکتر نازنین فرحبخش\n- ۰۹:۴۵ - ۰۹:۳۰: بیماری‌های قلبی و ویزینگ - دکتر فریبا عالی\n\n**پنل دوم: آسم**\nگردانندگان پنل: دکتر فریناز امیری‌کار، دکتر قمرتاج خانبابایی، دکتر امیر رضایی، دکتر لعبت شاهکار، دکتر علیرضا عشقی\n\n- ۱۰:۵۰ - ۱۰:۳۰: کلیات، تشخیص و تشخیص‌های افتراقی آسم - دکتر سهیلا حکم‌آبادی\n- ۱۱:۱۰ - ۱۰:۵۰: درمان حمله آسم - دکتر امیر رضائی\n- ۱۱:۳۰ - ۱۱:۱۰: درمان نگهدارنده آسم - دکتر لعبت شاهکار\n- ۱۱:۵۰ - ۱۱:۳۰: تعریف و مدیریت آسم مقاوم به درمان - دکتر آذر دسترنجی\n- ۱۲:۱۰ - ۱۱:۵۰: اداره بیمار آسم تحت ونتیلاتور - دکتر امیر رضائی\n- ۱۲:۳۰ - ۱۲:۱۰: محرک‌های داخل منزل و راهکارهای مقابله - دکتر فریناز امیری‌کار\n- ۱۲:۵۰ - ۱۲:۳۰: محرک‌های خارج منزل و راهکارهای مقابله - دکتر کیوان ملکی مستشاری\n\n**پنل سوم: پنومونی**\nگردانندگان پنل: دکتر غلامرضا پناهنده، دکتر علی عظیمی، دکتر معصومه قاسمپور، دکتر کیوان ملکی مستشاری\n\n- ۱۴:۲۰ - ۱۴:۰۰: تشخیص و درمان پنومونی حاد باکتریال - دکتر علی عظیمی\n- ۱۴:۴۰ - ۱۴:۲۰: تشخیص و درمان پنومونی ویروسی - دکتر مائده سفالئی\n- ۱۵:۰۰ - ۱۴:۴۰: تشخیص و درمان پنومونی آتیپیک - دکتر عبدالحمید تقی‌زاده\n- ۱۵:۲۰ - ۱۵:۰۰: تشخیص و اداره بیمار مبتلا به ARDS - دکتر آزیتا بهزاد\n- ۱۵:۴۰ - ۱۵:۲۰: پیشگیری از پنومونی در کودکان - دکتر سیدجواد سیدی\n- ۱۶:۰۰ - ۱۵:۴۰: تشخیص و درمان پلورال افیوژن - دکتر غلامرضا پناهنده\n- ۱۶:۲۰ - ۱۶:۰۰: تشخیص و درمان شیلوتوراکس - دکتر سعید هاشمی\n- ۱۶:۴۰ - ۱۶:۲۰: تشخیص و درمان آمپیم - دکتر اکبر زمانی\n\n**مخاطبان:**\n- پزشکان عمومی\n- متخصصان کودکان\n- فوق تخصصان ریه کودکان\n- سایر متخصصان مرتبط\n\nاین همایش دارای امتیاز بازآموزی برای شرکت‌کنندگان می‌باشد.','congress','','تهران - بیمارستان کودکان مفید',NULL,NULL,0,1,1,'2024-03-31 20:30:00.000000','2026-07-03 18:21:30.399559',0,1,'روز اول - پنجشنبه ۳۱ خرداد ۱۴۰۳:\n- افتتاحیه: ۰۸:۰۰ - ۰۸:۱۵\n- پنل سرفه در کودکان: ۰۸:۱۵ - ۱۱:۰۰\n- پنل آئروسل تراپی: ۱۱:۰۰ - ۱۳:۳۰\n- پنل سیستیک فیبروزیس: ۱۳:۵۰ - ۱۵:۰۰\n- پنل مداخلات تشخیصی: ۱۵:۰۰ - ۱۶:۳۰\n\nروز دوم - جمعه ۱ تیر ۱۴۰۳:\n- پنل برخورد با ویزینگ: ۰۸:۰۰ - ۱۰:۳۰\n- پنل آسم: ۱۰:۳۰ - ۱۴:۰۰\n- پنل پنومونی: ۱۴:۲۰ - ۱۷:۰۰','تلفن: ۰۲۱-۸۸۸۷۴۸۸۵ | کد شناسه: ۲۱۲۳۶۴','',3,1403,'انجمن علمی ریه کودکان ایران',NULL,'پنجمین همایش سالیانه انجمن علمی ریه کودکان ایران در تاریخ ۳۱ خرداد و ۱ تیر ۱۴۰۳ در تهران برگزار می‌گردد.','دکتر امیرحسین جعفری روحی، دکتر روح‌الله شیرزادی، دکتر سعید صدر، دکتر صدیقه یوسف‌زادگان، دکتر محمد نیک‌پندار، دکتر علیرضا عشقی، دکتر سیدحسین میرلوحی، دکتر مهدی علیزاده، دکتر نفیسه فدوی، دکتر مریم حسن‌زاد، دکتر آذر دسترنجی، دکتر محمد رضائی، دکتر نرگس کشورپرست، دکتر ذلفا مدرسی، دکتر متین پورقاسم، دکتر قمرتاج خانبابایی، دکتر سهیلا خلیل‌زاده، دکتر سیدجواد سیدی، دکتر محمدرضا مدرسی، دکتر حسینعلی غفاری‌پور، دکتر عبدالحمید جعفری ندوشن، دکتر میترا خلیلی، دکتر شیلا محمدی، دکتر سعید هاشمی، دکتر فاطمه طریقت منفرد، دکتر معصومه قاسمپور، دکتر زهرا قمی، دکتر سیداحمد طباطبائی، دکتر سارا قهرمانی، دکتر مجید کیوانفر، دکتر نازنین فرحبخش، دکتر فریبا عالی، دکتر سهیلا حکم‌آبادی، دکتر امیر رضائی، دکتر لعبت شاهکار، دکتر فریناز امیری‌کار، دکتر کیوان ملکی مستشاری، دکتر غلامرضا پناهنده، دکتر علی عظیمی، دکتر مائده سفالئی، دکتر عبدالحمید تقی‌زاده، دکتر آزیتا بهزاد، دکتر سیدجواد سیدی، دکتر اکبر زمانی','پزشکان عمومی، متخصصان کودکان، فوق تخصصان ریه کودکان',NULL),(2,'چهارمین همایش سالیانه انجمن علمی ریه کودکان ایران (وبینار چهار روزه)','chaharomin-hamayesh-webinar-1400','چهارمین همایش سالیانه انجمن علمی ریه کودکان ایران در سال ۱۴۰۰ به صورت وبینار چهار روزه برگزار شد.\n\nاین همایش با همکاری دانشگاه علوم پزشکی جندی شاپور اهواز برگزار گردید و آخرین دستاوردهای علمی در زمینه بیماری‌های تنفسی کودکان را ارائه داد.\n\n**برنامه وبینار:**\n\n**روز اول: کووید ۱۹**\nپنجشنبه ۱۲ اسفند ۱۴۰۰، ساعت ۱۰ الی ۱۳\n\n**روز دوم: آسم کودکان**\nجمعه ۱۳ اسفند ۱۴۰۰، ساعت ۱۰ الی ۱۳\n\n**روز سوم: سمپتوماتولوژی بیماری‌های تنفسی**\nپنجشنبه ۱۹ اسفند ۱۴۰۰، ساعت ۱۰ الی ۱۳\n\n**روز چهارم: بیماری‌های حاد تنفسی**\nجمعه ۲۰ اسفند ۱۴۰۰، ساعت ۱۰ الی ۱۳\n\n**امتیاز بازآموزی:**\nاین همایش دارای دوازده امتیاز بازآموزی بود.\n\n**مخاطبان:**\n- پزشکان عمومی\n- متخصصان کودکان\n- فوق تخصصان ریه کودکان\n- فوق تخصصان عفونی کودکان\n- فوق تخصصان ریه بزرگسالان\n\n**لینک ثبت‌نام:**\nircme.ir\n\n**لینک شرکت در برنامه:**\nVc8.ajums.ac.ir/ch/seminar','congress','','آنلاین',NULL,NULL,0,1,0,'2022-01-01 20:30:00.000000','2026-07-03 18:21:30.412383',0,1,'','ircme.ir | Vc8.ajums.ac.ir/ch/seminar','',12,1400,'انجمن علمی ریه کودکان ایران',NULL,'چهارمین همایش سالیانه انجمن علمی ریه کودکان ایران به صورت وبینار چهار روزه در اسفند ۱۴۰۰ برگزار شد.','','پزشکان عمومی، متخصصان کودکان، فوق تخصصان ریه کودکان',NULL),(3,'سومین کنگره سراسری بیماری‌های تنفسی کودکان','sevomin-kongre-bimarihaye-tanafosi-1398','سومین کنگره سراسری بیماری‌های تنفسی کودکان در تاریخ ۳۰ آبان و ۱ آذر ۱۳۹۸ در گرگان برگزار شد.\n\nاین کنگره با همکاری دانشگاه علوم پزشکی گلستان و انجمن علمی ریه کودکان ایران برگزار گردید.\n\n**کارگاه:**\nکارگاه تهویه مکانیکی در کودکان (۲۹ آبان ۱۳۹۸)\n\n**محورهای کنگره:**\n- نبولایزر تراپی\n- آسم در کودکان\n- بیماری‌های پلور\n- عفونت‌های ریوی\n- مراقبت‌های بخش ویژه\n- بیماری‌های کیستیک ریه\n- سیستیک فیبروزیس و برونشکتازی در کودکان و بالغین\n- برخورد با سرفه حاد و مزمن، آسپیراسیون جسم خارجی\n- سونوگرافی و برونکوسکوپی در بیماری‌های ریوی کودکان\n\n**محل برگزاری:**\nمجموعه آموزش عالی فلسفی دانشگاه علوم پزشکی گلستان\n\n**مهلت ارسال مقالات:**\n۲۰ مهر ماه ۱۳۹۸\n\n**اطلاعات تماس:**\nتلفن: ۰۹۳۳۵۲۵۱۲۹۱\nایمیل: n.rajabi171@yahoo.com\n\n**وب‌سایت:**\nGoums.ac.ir/page/19034/-کنگره-بیماری-های-تنفسی-کودکان','congress','','گرگان - دانشگاه علوم پزشکی گلستان',NULL,NULL,0,1,0,'2019-10-01 20:30:00.000000','2026-07-03 18:21:30.428999',0,1,'','تلفن: ۰۹۳۳۵۲۵۱۲۹۱ | ایمیل: n.rajabi171@yahoo.com','',9,1398,'انجمن علمی ریه کودکان ایران',NULL,'سومین کنگره سراسری بیماری‌های تنفسی کودکان در تاریخ ۳۰ آبان و ۱ آذر ۱۳۹۸ در گرگان برگزار شد.','','پزشکان عمومی، متخصصان کودکان، فوق تخصصان ریه کودکان',NULL),(4,'ششمین سمینار سالانه بیماری‌های تنفسی کودکان','sheshomin-seminar-bimarihaye-tanafosi-1404','ششمین سمینار سالانه انجمن علمی ریه کودکان ایران با موضوع بیماری‌های تنفسی کودکان برگزار می‌گردد.\n\nاین سمینار با هدف ارائه آخرین دستاوردهای علمی و تبادل تجربیات متخصصان در زمینه بیماری‌های تنفسی کودکان برگزار می‌شود.\n\n**تاریخ و مکان:**\nسمینار در تاریخ ۲۹ و ۳۰ آبان ۱۴۰۴ در تهران، هتل بزرگ ارم برگزار خواهد شد.\n\n**شناسه برنامه:**\n۲۴۲۵۹۱\n\n**امتیاز بازآموزی:**\nاین سمینار دارای ۱۰ امتیاز بازآموزی است.\n\n**مخاطبان:**\n- فوق تخصصان ریه کودکان و ریه بزرگسالان\n- متخصصان کودکان\n- پزشکان عمومی\n- سایر فوق تخصصان کودکان\n- متخصصان داخلی، گوش و حلق و بینی\n\n**اسپانسرها:**\n- Vitabiotics\n- AstraZeneca\n- Actoverco\n- Koushan Pharmed\n- IGG (ایده گستر قدرت)','seminar','','تهران - هتل بزرگ ارم',NULL,NULL,0,1,1,'2025-08-31 20:30:00.000000','2026-07-03 18:21:30.434071',1,1,'','شناسه برنامه: ۲۴۲۵۹۱','',8,1404,'انجمن علمی ریه کودکان ایران',NULL,'ششمین سمینار سالانه انجمن علمی ریه کودکان ایران در تاریخ ۲۹ و ۳۰ آبان ۱۴۰۴ در تهران برگزار می‌گردد.','','فوق تخصصان ریه کودکان، متخصصان کودکان، پزشکان عمومی',NULL),(5,'وبینار روز جهانی آسم ۲۰۲۵','webinar-world-asthma-day-2025','انجمن علمی ریه کودکان ایران به مناسبت روز جهانی آسم ۲۰۲۵ وبینار تخصصی برگزار می‌کند.\n\nاین وبینار با هدف ارائه آخرین دستاوردهای علمی در زمینه آسم کودکان و تبادل تجربیات متخصصان برگزار می‌گردد.\n\n**زمان:**\n۱۶ اردیبهشت ۱۴۰۴، از ساعت ۹ تا ۱۲\n\n**موضوع:**\nموارد کاربردی در آسم کودکان\n\n**مخاطبان:**\nویژه پزشکان عمومی، متخصصین اطفال، فوق تخصصین ریه کودکان، ایمونولوژی و آلرژی\n\n**همکاری:**\nبا همکاری دانشگاه علوم پزشکی یزد\n\n**امتیاز بازآموزی:**\nدارای ۳ امتیاز بازآموزی\n\n**دبیر علمی:**\nدکتر سیده ذلفا مدرسی\n\n**شناسه وبینار:**\n۲۳۳۶۸۸','seminar','','آنلاین',NULL,NULL,0,1,0,'2025-03-01 20:30:00.000000','2026-07-03 18:21:30.438724',0,1,'','شناسه وبینار: ۲۳۳۶۸۸','',2,1404,'انجمن علمی ریه کودکان ایران',NULL,'وبینار روز جهانی آسم ۲۰۲۵ با موضوع موارد کاربردی در آسم کودکان در ۱۶ اردیبهشت ۱۴۰۴ برگزار می‌گردد.','','پزشکان عمومی، متخصصین اطفال، فوق تخصصین ریه کودکان',NULL),(6,'وبینار روز جهانی پنومونی','webinar-world-pneumonia-day-1404','انجمن علمی ریه کودکان ایران به مناسبت روز جهانی پنومونی وبینار علمی-آموزشی برگزار می‌کند.\n\nاین وبینار با هدف ارائه آخرین دستاوردهای علمی در زمینه پیشگیری و مدیریت پنومونی در کودکان برگزار می‌گردد.\n\n**موضوع:**\nپیشگیری و مدیریت پنومونی در کودکان\n\n**تاریخ و زمان:**\n۲۲ آبان ۱۴۰۴، ساعت ۹ الی ۱۲ صبح\n\n**مکان:**\nآنلاین در بستر اسکای روم\n\n**امتیاز بازآموزی:**\n۳ امتیاز برای فوق تخصصان ریه کودکان، متخصصان کودکان، پزشکان عمومی و سایر فوق تخصصان کودکان\n\n**دبیر علمی:**\nدکتر سیده ذلفا مدرسی (عضو هیئت علمی دانشگاه علوم پزشکی شهید صدوقی یزد)\n\n**شناسه برنامه:**\n۲۴۵۰۰۵','seminar','','آنلاین',NULL,NULL,0,1,0,'2025-08-31 20:30:00.000000','2026-07-03 18:21:30.443443',0,1,'','شناسه برنامه: ۲۴۵۰۰۵','',8,1404,'انجمن علمی ریه کودکان ایران',NULL,'وبینار روز جهانی پنومونی با موضوع پیشگیری و مدیریت پنومونی در کودکان در ۲۲ آبان ۱۴۰۴ برگزار می‌گردد.','','فوق تخصصان ریه کودکان، متخصصان کودکان، پزشکان عمومی',NULL),(7,'اولین کنگره سراسری بیماری‌های تنفسی کودکان','avalin-kongre-bimarihaye-tanafosi-1396','اولین کنگره سراسری بیماری‌های تنفسی کودکان در تاریخ ۲۸ و ۲۹ دی ماه ۱۳۹۶ در اهواز برگزار شد.\n\nاین کنگره توسط گروه کودکان دانشگاه جندی شاپور با همکاری انجمن علمی ریه کودکان برگزار گردید.\n\n**موضوعات همایش:**\n- بیماری‌های مادرزادی ریه\n- آسم کودکان\n- سیستیک فیبروزیس و برونشکتازی\n- بیماری‌های معینی\n- بیماری‌های تنفسی نوزادان\n- اقدامات تشخیصی درمانی جدید\n- برخورد با کودک بدحال و نیازمند مراقبت‌های ویژه\n\n**زمان ارسال مقاله:**\n۳۰ آذر ۱۳۹۶\n\n**امتیاز:**\nدارای ۱۰ امتیاز کامل بازآموزی برای رشته‌های مرتبط و دارای امتیاز برای همکاران پرستاری\n\n**اطلاعات تماس:**\nآدرس دبیرخانه: اهواز، بیمارستان ابوالفضل، مرکز آموزشی درمانی کودکان، گروه آموزشی بیماری‌های کودکان\nوب‌سایت: Card.ajums.ac.ir\nتلفن: ۰۹۱۶۳۱۱۳۹۱۶ – ۰۳۱-۳۴۴۴۴۲۱۱\n\nدر این همایش اساتید برجسته فوق تخصص کودکان، آسم و آلرژی، نوزادان، گوارش، قلب، ریه بالغین، رادیولوژی و ICU حضور داشتند.','congress','','اهواز - بیمارستان ابوالفضل',NULL,NULL,0,1,0,'2017-10-31 20:30:00.000000','2026-07-03 18:21:30.448088',0,1,'','تلفن: ۰۹۱۶۳۱۱۳۹۱۶ – ۰۳۱-۳۴۴۴۴۲۱۱','',10,1396,'گروه کودکان دانشگاه جندی شاپور',NULL,'اولین کنگره سراسری بیماری‌های تنفسی کودکان در تاریخ ۲۸ و ۲۹ دی ماه ۱۳۹۶ در اهواز برگزار شد.','','پزشکان عمومی، متخصصان کودکان، فوق تخصصان ریه کودکان',NULL),(8,'وبینار تازه‌های تشخیصی و درمانی در CF (سیستیک فیبروزیس)','webinar-cf-diagnosis-treatment','وبینار تخصصی و فوق‌تخصصی دو روزه در مورد تازه‌های تشخیصی و درمانی در CF (سیستیک فیبروزیس) برگزار شد.\n\nاین وبینار توسط دانشگاه علوم پزشکی جندی شاپور اهواز و انجمن ریه کودکان با همکاری کوشان فارمد برگزار گردید.\n\n**تاریخ و زمان وبینار:**\n\n**روز اول:**\n۱۸ دی ماه، ساعت ۰۸:۰۰ الی ۲۰:۰۰\n\n**روز دوم:**\n۱۹ دی ماه، ساعت ۱۰:۰۰ الی ۲۰:۰۰\n\n**لینک ورود به برنامه:**\nhttps://www.skyroom.online/ch/koushanpharmed/tobamist\n\n**شرکت‌های همکار:**\nکوشان فارمد، Tobamist، Cipla\n\nاین وبینار با حضور اساتید و متخصصین برجسته در زمینه سیستیک فیبروزیس برگزار شد و آخرین دستاوردهای علمی در زمینه تشخیص و درمان این بیماری ارائه گردید.','seminar','','آنلاین',NULL,NULL,0,1,0,'2020-10-31 20:30:00.000000','2026-07-03 18:21:30.453334',0,1,'','skyroom.online/ch/koushanpharmed/tobamist','',10,1399,'انجمن علمی ریه کودکان ایران',NULL,'وبینار تخصصی دو روزه در مورد تازه‌های تشخیصی و درمانی در CF (سیستیک فیبروزیس) برگزار شد.','','پزشکان عمومی، متخصصان کودکان، فوق تخصصان ریه کودکان',NULL);
/*!40000 ALTER TABLE `events_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events_eventregistration`
--

DROP TABLE IF EXISTS `events_eventregistration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events_eventregistration` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `registered_at` datetime(6) NOT NULL,
  `is_confirmed` tinyint(1) NOT NULL,
  `notes` longtext COLLATE utf8mb4_unicode_ci,
  `event_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `events_eventregistration_event_id_user_id_a8aa6b7c_uniq` (`event_id`,`user_id`),
  KEY `events_eventregistra_user_id_d0835e90_fk_accounts_` (`user_id`),
  CONSTRAINT `events_eventregistra_user_id_d0835e90_fk_accounts_` FOREIGN KEY (`user_id`) REFERENCES `accounts_customuser` (`id`),
  CONSTRAINT `events_eventregistration_event_id_9b88b424_fk_events_event_id` FOREIGN KEY (`event_id`) REFERENCES `events_event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events_eventregistration`
--

LOCK TABLES `events_eventregistration` WRITE;
/*!40000 ALTER TABLE `events_eventregistration` DISABLE KEYS */;
/*!40000 ALTER TABLE `events_eventregistration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news_announcement`
--

DROP TABLE IF EXISTS `news_announcement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news_announcement` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL,
  `is_important` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `views` int NOT NULL,
  `author_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `news_announcement_author_id_5b87f6b1_fk_accounts_customuser_id` (`author_id`),
  CONSTRAINT `news_announcement_author_id_5b87f6b1_fk_accounts_customuser_id` FOREIGN KEY (`author_id`) REFERENCES `accounts_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news_announcement`
--

LOCK TABLES `news_announcement` WRITE;
/*!40000 ALTER TABLE `news_announcement` DISABLE KEYS */;
INSERT INTO `news_announcement` VALUES (1,'دروددددد','یحبخهعلغرذدئنمخح','دلم میخواد برم به دریا','',1,1,'2026-07-03 18:21:29.937515','2026-07-03 18:21:29.938449',0,1),(2,'کنگره بیماری‌های ریوی کودکان ۱۴۰۳','kongre-bimarihaye-riuye-kodakan-1403','انجمن علمی ریه کودکان ایران با افتخار برگزاری کنگره بیماری‌های ریوی کودکان ۱۴۰۳ را اعلام می‌کند.\n\nاین کنگره در تاریخ ۳۱ خرداد لغایت ۲ تیر ماه ۱۴۰۳، در شهر تهران (خیابان شریعتی، نرسیده به میرداماد، بیمارستان کودکان مفید) برگزار می‌گردد.\n\n**اهداف کنگره:**\n- ارائه آخرین دستاوردهای علمی در زمینه بیماری‌های ریه کودکان\n- تبادل دانش و مهارت‌های علمی جدید بین شرکت‌کنندگان\n- ارتقای سطح علمی و بالینی متخصصان\n- ایجاد بستری برای همکاری و تعامل علمی\n\n**دبیر علمی کنگره:**\nسرکار خانم دکتر قمرتاج خان‌بابائی\n\n**اعضاء کمیته علمی:**\nدکتر مجید کیوانفر، دکتر امیر رضائی، دکتر محمد رضائی، دکتر سیدمحمدرضا میرکریمی، دکتر سید حسین میرلوحی، دکتر علیرضا عشقی، دکتر لعبت شاهکار، دکتر قمرتاج خان بابائی، دکتر نازنین فرح بخش، دکتر سید احمد طباطبائی عقدائی، دکتر سهیلا خلیل زاده\n\n**اطلاعات تماس:**\nتلفن واحد مجری: ۰۲۱-۸۸۸۷۴۸۸۵\n\nبرای اطلاعات و جزئیات بیشتر جهت شرکت در کنگره، به سایت آموزش مداوم با کد شناسه ۲۱۲۳۶۴ مراجعه شود.','',1,1,'2024-12-16 10:00:00.000000','2026-07-03 18:21:30.367367',0,1);
/*!40000 ALTER TABLE `news_announcement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news_news`
--

DROP TABLE IF EXISTS `news_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news_news` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `views` int NOT NULL,
  `author_id` bigint NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_content` longtext COLLATE utf8mb4_unicode_ci,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `news_news_author_id_9f88be71_fk_accounts_customuser_id` (`author_id`),
  CONSTRAINT `news_news_author_id_9f88be71_fk_accounts_customuser_id` FOREIGN KEY (`author_id`) REFERENCES `accounts_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news_news`
--

LOCK TABLES `news_news` WRITE;
/*!40000 ALTER TABLE `news_news` DISABLE KEYS */;
INSERT INTO `news_news` VALUES (1,'درود و مهر','2ROOD','سلام سلام مو مهر','',1,'2026-07-03 18:21:29.846286','2026-07-03 18:21:29.848575',3,1,'','','',''),(2,'رئیس انجمن ریه کودکان هشدار داد: مصرف دخانیات در میان نوجوانان نگران‌کننده است','hoshdar-masraf-dokhaniyat-noghavanan','رئیس انجمن علمی ریه کودکان ایران با بیان اینکه بیماری‌های تنفسی در کودکان هم‌زمان با تشدید آلودگی هوا افزایش چشمگیر دارد، هشدار داد که مصرف دخانیات در میان نوجوانان بسیار نگران‌کننده است.\n\nدکتر قمرتاج خان‌بابایی، فوق‌تخصص آسم و آلرژی کودکان، رئیس انجمن علمی ریه کودکان ایران و استاد تمام دانشگاه علوم پزشکی شهید بهشتی، در حاشیه برگزاری کنگره دو روزه بیماری‌های ریه کودکان گفت: تازه‌ترین مقالات و دستاوردهای علمی حوزه بیماری‌های تنفسی در این رویداد ارائه شده و در اختیار فوق‌تخصصان ریه، متخصصان کودکان و پزشکان عمومی قرار گرفته است.\n\nوی افزود: بیماری‌های ریوی از شایع‌ترین دلایل مراجعه کودکان به اورژانس‌ها محسوب می‌شود. ازاین‌رو ارائه به‌روزترین دستاوردهای علمی در کنار برگزاری پنل‌های تخصصی با حضور اساتید شاخص، به ارتقای دانش بالینی و بهبود کیفیت درمان کمک می‌کند.\n\n**افزایش روند بیماری‌های تنفسی با صنعتی‌شدن شهرها**\n\nدکتر خان‌بابایی با اشاره به روند رو‌به‌افزایش بیماری‌های ریوی کودکان در سال‌های اخیر اظهار کرد: افزایش بیماری‌های تنفسی موضوعی جهانی است و کشور ما نیز از این قاعده مستثنی نیست. صنعتی‌شدن شهرها، افزایش آلاینده‌ها و مصرف مواد افزودنی، زمینه‌ساز بروز و تشدید بیماری‌های ریوی و آلرژیک در کودکان شده است.\n\nوی تأکید کرد: اگرچه پس از پاندمی کووید-۱۹، آگاهی عمومی درباره پیشگیری از بیماری‌ها افزایش یافته، اما رشد آلایندگی‌ها موجب تقویت بیماری‌های مزمن التهابی ریه می‌شود.\n\n**تأثیر آلودگی هوا و ریزگردها**\n\nرئیس انجمن علمی ریه کودکان ایران با اشاره به نقش مستقیم آلودگی هوا و ریزگردها در تشدید علائم تنفسی کودکان، بیان کرد: بررسی‌ها نشان می‌دهد در روزهایی که آلودگی هوا یا ریزگردها افزایش می‌یابد، آمار مراجعه به اورژانس‌ها و میزان بستری کودکان به‌طور قابل‌توجهی افزایش دارد. حتی بیماران کنترل‌شده نیز دچار تشدید علائم شده و نیازمند افزایش دوز دارو می‌شوند.\n\n**هشدار درباره مصرف فزاینده دخانیات**\n\nدکتر خان‌بابایی با ابراز نگرانی نسبت به افزایش مصرف دخانیات و قلیان در میان کودکان و نوجوانان تصریح کرد: متأسفانه امروز مصرف قلیان در فضای عمومی بسیار گسترده شده و حتی برخی خانواده‌ها قلیان را مانند غذا به منازل سفارش می‌دهند. مشاهده مصرف دخانیات در میان دانش‌آموزان دبستانی و نوجوانان بسیار نگران‌کننده است.\n\nوی همچنین نسبت به استفاده از ماری‌جوانا و مواد مشابه در بین نوجوانان هشدار داد و افزود: مصرف مواد دخانی و روان‌گردان سبب بروز رفتارهای پرخطر شده و آسیب‌های آن به‌مراتب بیش از سیگار است. نخستین گام پیشگیری، محدودسازی مصرف دخانیات در اماکن عمومی و افزایش کنترل بر محیط‌های پذیرایی است.','',1,'2024-12-16 10:00:00.000000','2026-07-03 18:21:30.310062',0,1,'بیماری‌های تنفسی','رئیس انجمن علمی ریه کودکان ایران هشدار داد که مصرف دخانیات در میان نوجوانان بسیار نگران‌کننده است و بیماری‌های تنفسی در کودکان هم‌زمان با تشدید آلودگی هوا افزایش چشمگیر دارد.','شفقنا','ریه کودکان, بیماری‌های تنفسی, سلامت کودکان, دخانیات, آلودگی هوا'),(3,'افزایش چشمگیر بیماری‌های تنفسی در کودکان','afzayesh-bimarihaye-tanafosi-kodakan','رئیس انجمن ریه کودکان با بیان اینکه بیماری‌های تنفسی در کودکان هم‌زمان با تشدید آلودگی هوا افزایش چشمگیر دارد، بر لزوم توجه بیشتر به این موضوع تأکید کرد.\n\nبیماری‌های ریوی از شایع‌ترین دلایل مراجعه کودکان به اورژانس‌ها محسوب می‌شود. این موضوع اهمیت ارائه به‌روزترین دستاوردهای علمی و برگزاری پنل‌های تخصصی با حضور اساتید شاخص را نشان می‌دهد.\n\n**عوامل مؤثر در افزایش بیماری‌های تنفسی**\n\nصنعتی‌شدن شهرها، افزایش آلاینده‌ها و مصرف مواد افزودنی، زمینه‌ساز بروز و تشدید بیماری‌های ریوی و آلرژیک در کودکان شده است. اگرچه پس از پاندمی کووید-۱۹، آگاهی عمومی درباره پیشگیری از بیماری‌ها افزایش یافته، اما رشد آلایندگی‌ها موجب تقویت بیماری‌های مزمن التهابی ریه می‌شود.\n\nبررسی‌ها نشان می‌دهد در روزهایی که آلودگی هوا یا ریزگردها افزایش می‌یابد، آمار مراجعه به اورژانس‌ها و میزان بستری کودکان به‌طور قابل‌توجهی افزایش دارد. حتی بیماران کنترل‌شده نیز دچار تشدید علائم شده و نیازمند افزایش دوز دارو می‌شوند.\n\n**راهکارهای پیشنهادی**\n\nبرای کاهش تأثیر آلودگی هوا بر سلامت کودکان، لازم است اقدامات پیشگیرانه بیشتری انجام شود. این اقدامات شامل کاهش آلاینده‌ها، افزایش آگاهی عمومی و بهبود سیستم‌های درمانی می‌باشد.','',1,'2024-12-16 10:00:00.000000','2026-07-03 18:21:30.353975',0,1,'بیماری‌های تنفسی','بیماری‌های تنفسی در کودکان هم‌زمان با تشدید آلودگی هوا افزایش چشمگیر دارد و از شایع‌ترین دلایل مراجعه کودکان به اورژانس‌ها محسوب می‌شود.','مهرنیوز','ریه کودکان, بیماری‌های تنفسی, آلودگی هوا, سلامت کودکان'),(4,'تاریخچه انجمن علمی ریه کودکان ایران','tarikhche-anjoman-riye-kodakan-iran','انجمن علمی ریه کودکان ایران در سال ۱۳۹۵ در تهران تأسیس شد. این انجمن با هدف ارتقای سطح علمی، آموزشی و پژوهشی در حوزه بیماری‌های تنفسی کودکان و ایجاد بستری برای تبادل دانش میان متخصصان و پژوهشگران این رشته آغاز به کار کرد. اعضای مؤسس انجمن را گروهی از اساتید و فوق‌تخصص‌های ریه کودکان تشکیل می‌دهند که با احساس نیاز به هماهنگی علمی و تبادل تجربیات در سطح ملی، پایه‌گذار این حرکت ارزشمند شدند.\n\n**اهداف و رسالت**\n\nانجمن علمی ریه کودکان ایران با اهداف زیر فعالیت می‌کند:\n\n- ارتقای دانش تخصصی پزشکان و اعضای انجمن از طریق برگزاری کنگره‌ها، سمینارها، کارگاه‌ها و وبینارهای علمی\n- ترویج پژوهش‌های علمی و بالینی در زمینه بیماری‌های ریه کودکان\n- همکاری با نهادهای آموزشی و پژوهشی در تدوین و بازنگری راهنماهای بالینی و پروتکل‌های درمانی\n- افزایش آگاهی عمومی نسبت به پیشگیری و مراقبت از بیماری‌های تنفسی در کودکان\n\n**فعالیت‌های علمی**\n\nاز زمان تأسیس تاکنون، انجمن علمی ریه کودکان ایران با برگزاری کنگره‌های سالیانه، سمینارها و وبینارهای تخصصی متعدد نقش مؤثری در ارتقای دانش جامعه پزشکی و تبادل تجربیات علمی ایفا کرده است.\n\n**دفتر انجمن**\n\nدر سومین دوره هیئت‌مدیره، تحت ریاست سرکار خانم دکتر قمرتاج خانبابایی، دفتر انجمن به بیمارستان مفید منتقل شد. این انتقال دسترسی بهتر اعضا به امکانات علمی و آموزشی بیمارستان و هماهنگی مؤثرتر برای فعالیت‌های تخصصی را فراهم ساخت.\n\n**دستاوردها**\n\nتا کنون سمینارها، کنگره‌های سالیانه و وبینارهای متعددی توسط انجمن برگزار شده است که به ارتقای آموزش و تقویت شبکهٔ تخصصی ریه کودکان در کشور کمک کرده‌اند.','',1,'2024-12-16 10:00:00.000000','2026-07-03 18:21:30.362325',0,1,'تاریخچه','انجمن علمی ریه کودکان ایران در سال ۱۳۹۵ در تهران تأسیس شد و با هدف ارتقای سطح علمی، آموزشی و پژوهشی در حوزه بیماری‌های تنفسی کودکان فعالیت می‌کند.','انجمن علمی ریه کودکان ایران','تاریخچه, انجمن علمی ریه کودکان, تأسیس, اهداف'),(5,'جلسه ارزیابی عملکرد و اعتباربخشی انجمن علمی ریه کودکان ایران','جلسه-ارزیابی-عملکرد-و-اعتباربخشی-انجمن-علمی-ریه-کودکان-ایران','<hr /><p><strong>فایل‌های مرتبط:</strong></p><p><a href=\"/Content/%D8%A7%D8%B1%D8%B2%DB%8C%D8%A7%D8%A8%DB%8C%20.pdf\" target=\"_blank\" rel=\"noopener\">مشاهده فایل ارزیابی (PDF)</a></p><p><a href=\"/Content/IMG_5403.jpeg\" target=\"_blank\" rel=\"noopener\">مشاهده تصویر ۱</a></p><p><a href=\"/Content/IMG_5400.jpeg\" target=\"_blank\" rel=\"noopener\">مشاهده تصویر ۲</a></p>','',1,'2026-07-03 18:21:26.433767','2026-07-03 18:21:30.527548',0,1,'اخبار انجمن','گزارش نشست ارزیابی عملکرد و اعتباربخشی سال‌های ۱۴۰۲ و ۱۴۰۳ انجمن علمی ریه کودکان ایران به همراه فایل‌ها و تصاویر مرتبط.','/Content/%D8%A7%D8%B1%D8%B2%DB%8C%D8%A7%D8%A8%DB%8C%20.pdf','ارزیابی, اعتباربخشی, انجمن, ریه کودکان');
/*!40000 ALTER TABLE `news_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'irporg_DB'
--

--
-- Dumping routines for database 'irporg_DB'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-03 19:00:45
